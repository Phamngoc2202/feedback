-- ==========================================================
-- SCRIPT TẠO BẢNG VÀ NẠP DỮ LIỆU CHO PHÂN HỆ GIẢNG VIÊN (TEACHER)
-- DATABASE: teacher_feedback_db
-- ==========================================================

USE teacher_feedback_db;
GO

-- 1. Tạo bảng classes (Lớp học phần phân công cho giảng viên)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'classes')
BEGIN
    CREATE TABLE classes (
        class_id INT IDENTITY(1,1) PRIMARY KEY,
        class_code NVARCHAR(50) NOT NULL,
        course_id INT NOT NULL,
        teacher_id INT NOT NULL,
        semester_id INT NOT NULL,
        total_students INT DEFAULT 30,
        FOREIGN KEY (course_id) REFERENCES courses(course_id),
        FOREIGN KEY (teacher_id) REFERENCES users(user_id),
        FOREIGN KEY (semester_id) REFERENCES semesters(semester_id)
    );
END
GO

-- 2. Tạo bảng feedbacks (Bài đánh giá của sinh viên)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'feedbacks')
BEGIN
    CREATE TABLE feedbacks (
        feedback_id INT IDENTITY(1,1) PRIMARY KEY,
        form_id INT NOT NULL,
        class_id INT NOT NULL,
        course_id INT NOT NULL,
        teacher_id INT NOT NULL,
        student_id INT NULL,
        student_name NVARCHAR(100) DEFAULT N'Sinh viên ẩn danh',
        q1 INT CHECK (q1 BETWEEN 1 AND 5),
        q2 INT CHECK (q2 BETWEEN 1 AND 5),
        q3 INT CHECK (q3 BETWEEN 1 AND 5),
        q4 INT CHECK (q4 BETWEEN 1 AND 5),
        q5 INT CHECK (q5 BETWEEN 1 AND 5),
        q6 INT CHECK (q6 BETWEEN 1 AND 5),
        q7 INT CHECK (q7 BETWEEN 1 AND 5),
        q8 INT CHECK (q8 BETWEEN 1 AND 5),
        q9 INT CHECK (q9 BETWEEN 1 AND 5),
        average_score DECIMAL(3,1),
        comments NVARCHAR(MAX),
        created_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (form_id) REFERENCES feedback_forms(form_id),
        FOREIGN KEY (class_id) REFERENCES classes(class_id),
        FOREIGN KEY (course_id) REFERENCES courses(course_id),
        FOREIGN KEY (teacher_id) REFERENCES users(user_id)
    );
END
GO

-- 3. Tạo bảng feedback_replies (Giảng viên trả lời bình luận sinh viên)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'feedback_replies')
BEGIN
    CREATE TABLE feedback_replies (
        reply_id INT IDENTITY(1,1) PRIMARY KEY,
        feedback_id INT NOT NULL,
        teacher_id INT NOT NULL,
        reply_content NVARCHAR(MAX) NOT NULL,
        created_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (feedback_id) REFERENCES feedbacks(feedback_id),
        FOREIGN KEY (teacher_id) REFERENCES users(user_id)
    );
END
GO

-- 4. Chèn dữ liệu mẫu Lớp học (Classes) nếu chưa có
IF NOT EXISTS (SELECT * FROM classes WHERE class_code = 'SE1801-PRJ')
BEGIN
    -- Lấy ID của giảng viên đầu tiên (role_id = 2)
    DECLARE @TeacherId INT;
    SELECT TOP 1 @TeacherId = user_id FROM users WHERE role_id = 2;
    IF @TeacherId IS NULL SET @TeacherId = 2;

    -- Lấy ID môn học đầu tiên
    DECLARE @Course1 INT, @Course2 INT, @Course3 INT;
    SELECT TOP 1 @Course1 = course_id FROM courses ORDER BY course_id ASC;
    SELECT TOP 1 @Course2 = course_id FROM courses WHERE course_id > @Course1 ORDER BY course_id ASC;
    IF @Course2 IS NULL SET @Course2 = @Course1;

    -- Lấy ID học kỳ đầu tiên
    DECLARE @Sem1 INT;
    SELECT TOP 1 @Sem1 = semester_id FROM semesters ORDER BY semester_id DESC;
    IF @Sem1 IS NULL SET @Sem1 = 1;

    INSERT INTO classes (class_code, course_id, teacher_id, semester_id, total_students)
    VALUES 
    ('SE1801-PRJ', @Course1, @TeacherId, @Sem1, 32),
    ('SE1802-DBI', @Course2, @TeacherId, @Sem1, 30);
END
GO

-- 5. Chèn dữ liệu mẫu Đánh giá (Feedbacks) nếu chưa có
IF NOT EXISTS (SELECT * FROM feedbacks)
BEGIN
    DECLARE @TeacherId INT, @ClassId1 INT, @ClassId2 INT, @CourseId1 INT, @FormId INT;
    SELECT TOP 1 @TeacherId = user_id FROM users WHERE role_id = 2;
    IF @TeacherId IS NULL SET @TeacherId = 2;

    SELECT TOP 1 @ClassId1 = class_id, @CourseId1 = course_id FROM classes WHERE teacher_id = @TeacherId;
    IF @ClassId1 IS NULL SET @ClassId1 = 1;
    IF @CourseId1 IS NULL SET @CourseId1 = 1;

    SELECT TOP 1 @FormId = form_id FROM feedback_forms;
    IF @FormId IS NULL SET @FormId = 1;

    INSERT INTO feedbacks (form_id, class_id, course_id, teacher_id, student_name, q1, q2, q3, q4, q5, q6, q7, q8, q9, average_score, comments, created_at)
    VALUES
    (@FormId, @ClassId1, @CourseId1, @TeacherId, N'Sinh viên ẩn danh #1', 5, 5, 4, 5, 5, 5, 4, 5, 5, 4.8, N'Thầy giảng bài rất nhiệt tình, giải thích cặn kẽ về mô hình MVC và JSP/Servlet. Mong thầy hướng dẫn thêm các mẹo tối ưu kết nối JDBC connection pool.', DATEADD(day, -3, GETDATE())),
    (@FormId, @ClassId1, @CourseId1, @TeacherId, N'Sinh viên ẩn danh #2', 5, 5, 5, 5, 4, 5, 5, 5, 5, 4.9, N'Bài giảng thực tế, bài tập lab bám sát đồ án assignment. Thầy chấm điểm rất công bằng và đưa ra nhận xét chi tiết giúp em sửa lỗi nhanh chóng.', DATEADD(day, -2, GETDATE())),
    (@FormId, @ClassId1, @CourseId1, @TeacherId, N'Sinh viên ẩn danh #3', 4, 4, 5, 5, 4, 4, 4, 5, 4, 4.3, N'Thầy nói hơi nhanh ở phần Authentication Filter và Session Management, mong thầy giảng chậm lại một chút ở các phần bảo mật ạ.', DATEADD(day, -1, GETDATE()));

    -- Chèn phản hồi mẫu của giảng viên
    DECLARE @FbId INT;
    SELECT TOP 1 @FbId = feedback_id FROM feedbacks;
    IF @FbId IS NOT NULL
    BEGIN
        INSERT INTO feedback_replies (feedback_id, teacher_id, reply_content, created_at)
        VALUES (@FbId, @TeacherId, N'Cảm ơn em đã đóng góp ý kiến! Thầy sẽ dành thêm 15 phút ở cuối mỗi buổi lab để giải đáp cụ thể hơn về phần Servlet & MVC.', GETDATE());
    END
END
GO
