<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Account - Feedback System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            background: #0f172a;
        }

        /* Left panel */
        .left-panel {
            flex: 1.1;
            background: linear-gradient(160deg, #0f172a 0%, #1e3a8a 55%, #1e40af 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 70px 80px;
            color: #f8fafc;
        }

        .left-panel .brand {
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: #93c5fd;
            margin-bottom: 28px;
        }

        .left-panel h1 {
            font-size: 42px;
            font-weight: 700;
            line-height: 1.25;
            margin-bottom: 20px;
            max-width: 480px;
        }

        .left-panel p {
            font-size: 17px;
            line-height: 1.7;
            color: #cbd5e1;
            max-width: 440px;
            margin-bottom: 24px;
        }

        .feature-list {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 10px;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 15px;
            color: #e2e8f0;
        }

        .feature-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            background: rgba(147, 197, 253, 0.2);
            border-radius: 50%;
            color: #93c5fd;
            font-size: 13px;
            font-weight: bold;
        }

        /* Right panel */
        .right-panel {
            width: 580px;
            background: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 50px;
            overflow-y: auto;
        }

        .register-box {
            width: 100%;
            max-width: 440px;
        }

        .register-box h2 {
            font-size: 28px;
            font-weight: 700;
            color: #111827;
            margin-bottom: 6px;
        }

        .register-box .subtitle {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 24px;
        }

        .error-box {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #b91c1c;
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 6px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 11px 14px;
            border: 1.5px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            color: #111827;
            background: #fff;
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #1e40af;
            box-shadow: 0 0 0 3px rgba(30, 64, 175, 0.15);
        }

        .btn-register {
            width: 100%;
            padding: 13px;
            background: #1e40af;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.15s ease, transform 0.1s ease;
            margin-top: 8px;
        }

        .btn-register:hover {
            background: #1e3a8a;
        }

        .btn-register:active {
            transform: scale(0.99);
        }

        .signin-prompt {
            margin-top: 24px;
            text-align: center;
            font-size: 14px;
            color: #4b5563;
        }

        .signin-prompt a {
            color: #1e40af;
            font-weight: 600;
            text-decoration: none;
            transition: color 0.15s ease;
        }

        .signin-prompt a:hover {
            text-decoration: underline;
            color: #1e3a8a;
        }

        .footer-text {
            margin-top: 28px;
            text-align: center;
            font-size: 13px;
            color: #9ca3af;
        }

        @media (max-width: 960px) {
            body {
                flex-direction: column;
            }
            .left-panel {
                padding: 40px 24px;
                min-height: auto;
            }
            .left-panel h1 {
                font-size: 28px;
            }
            .left-panel p {
                font-size: 14px;
            }
            .right-panel {
                width: 100%;
                flex: 1;
                padding: 36px 24px;
            }
            .form-row {
                grid-template-columns: 1fr;
                gap: 0;
            }
        }
    </style>
</head>
<body>
    <div class="left-panel">
        <div class="brand">Feedback System</div>
        <h1>Join the Community</h1>
        <p>Create your account today to participate in course evaluations, provide meaningful feedback, and track performance results.</p>
        
        <div class="feature-list">
            <div class="feature-item">
                <span class="feature-icon">✓</span>
                <span>Evaluate courses & instructors securely</span>
            </div>
            <div class="feature-item">
                <span class="feature-icon">✓</span>
                <span>Fast & transparent feedback submissions</span>
            </div>
            <div class="feature-item">
                <span class="feature-icon">✓</span>
                <span>Personalized student and teacher dashboards</span>
            </div>
        </div>
    </div>

    <div class="right-panel">
        <div class="register-box">
            <h2>Create Account</h2>
            <p class="subtitle">Enter your details to create a new account</p>

            <% if (request.getAttribute("error") != null) { %>
                <div class="error-box">${requestScope.error}</div>
            <% } %>

            <form action="${pageContext.request.contextPath}/register" method="POST">
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="fullname" value="${requestScope.regFullName}" placeholder="e.g. Nguyen Van A" required autofocus>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Username *</label>
                        <input type="text" name="username" value="${requestScope.regUsername}" placeholder="e.g. student01" required>
                    </div>

                    <div class="form-group">
                        <label>Account Role *</label>
                        <select name="roleId">
                            <option value="3" ${requestScope.regRoleId == '3' || empty requestScope.regRoleId ? 'selected' : ''}>Student</option>
                            <option value="2" ${requestScope.regRoleId == '2' ? 'selected' : ''}>Teacher</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" value="${requestScope.regEmail}" placeholder="e.g. student@university.edu.vn">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Password *</label>
                        <input type="password" name="password" placeholder="At least 6 characters" required>
                    </div>

                    <div class="form-group">
                        <label>Confirm Password *</label>
                        <input type="password" name="confirmPassword" placeholder="Re-enter password" required>
                    </div>
                </div>

                <button type="submit" class="btn-register">Sign Up</button>
            </form>

            <p class="signin-prompt">
                Already have an account? <a href="${pageContext.request.contextPath}/login">Sign in</a>
            </p>

            <p class="footer-text">© Feedback Management System</p>
        </div>
    </div>
</body>
</html>
