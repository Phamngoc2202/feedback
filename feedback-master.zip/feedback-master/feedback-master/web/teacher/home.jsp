<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - Feedback System</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Chart.js CDN for Advanced Statistics -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --primary: #059669;
            --primary-dark: #065f46;
            --primary-light: #d1fae5;
            --secondary: #2563eb;
            --secondary-light: #dbeafe;
            --dark-sidebar: #0f172a;
            --dark-sidebar-hover: #1e293b;
            --bg-page: #f8fafc;
            --card-bg: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --warning: #f59e0b;
            --danger: #ef4444;
            --success: #10b981;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: var(--bg-page);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 260px;
            background: var(--dark-sidebar);
            color: #e2e8f0;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            display: flex;
            flex-direction: column;
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 100;
        }

        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-icon {
            width: 38px;
            height: 38px;
            background: linear-gradient(135deg, #10b981, #059669);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 18px;
            color: #ffffff;
            box-shadow: 0 4px 10px rgba(16, 185, 129, 0.3);
        }

        .brand-text h2 {
            font-size: 16px;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.2;
        }

        .brand-text span {
            font-size: 11px;
            color: #94a3b8;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            padding: 20px 14px;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .nav-label {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            color: #64748b;
            padding: 8px 12px 4px;
            letter-spacing: 0.5px;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 14px;
            color: #cbd5e1;
            text-decoration: none;
            border-radius: 8px;
            font-size: 13.5px;
            font-weight: 600;
            transition: all 0.15s ease;
        }

        .sidebar-nav a:hover {
            background: var(--dark-sidebar-hover);
            color: #ffffff;
            transform: translateX(3px);
        }

        .sidebar-nav a.active {
            background: linear-gradient(135deg, #059669, #047857);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(5, 150, 105, 0.3);
        }

        .sidebar-nav a.logout {
            margin-top: auto;
            color: #fca5a5;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .sidebar-nav a.logout:hover {
            background: rgba(239, 68, 68, 0.15);
            color: #fecaca;
        }

        /* Main Content Container */
        .main {
            margin-left: 260px;
            flex: 1;
            padding: 30px 40px;
            max-width: 1350px;
        }

        /* Top Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 28px;
        }

        .header-title h1 {
            font-size: 24px;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: -0.5px;
        }

        .header-title p {
            font-size: 13.5px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .user-badge {
            display: flex;
            align-items: center;
            gap: 12px;
            background: #ffffff;
            padding: 8px 16px;
            border-radius: 30px;
            border: 1px solid var(--border-color);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
        }

        .user-avatar {
            width: 34px;
            height: 34px;
            background: #059669;
            color: #ffffff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
        }

        .user-info {
            text-align: right;
        }

        .user-info .name {
            font-size: 13.5px;
            font-weight: 700;
            color: var(--text-main);
            display: block;
        }

        .user-info .role-tag {
            font-size: 11px;
            color: #059669;
            font-weight: 600;
        }

        /* Flash Alerts */
        .alert {
            padding: 14px 20px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
            animation: slideDown 0.3s ease;
        }

        .alert-success {
            background: #ecfdf5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        .alert-error {
            background: #fef2f2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        /* Welcome & Filter Banner */
        .welcome-card {
            background: linear-gradient(135deg, #064e3b 0%, #059669 65%, #10b981 100%);
            border-radius: 16px;
            padding: 28px 32px;
            color: #ffffff;
            margin-bottom: 28px;
            box-shadow: 0 10px 25px -5px rgba(5, 150, 105, 0.35);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .welcome-content h2 {
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 6px;
        }

        .welcome-content p {
            font-size: 14px;
            color: #d1fae5;
            max-width: 650px;
            line-height: 1.5;
        }

        .filter-controls {
            display: flex;
            align-items: center;
            gap: 12px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            padding: 10px 16px;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.25);
        }

        .filter-controls label {
            font-size: 13px;
            font-weight: 600;
            color: #ffffff;
        }

        .filter-select {
            padding: 8px 14px;
            border-radius: 8px;
            border: none;
            background: #ffffff;
            color: #0f172a;
            font-size: 13.5px;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            outline: none;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            padding: 22px 24px;
            display: flex;
            align-items: center;
            gap: 18px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
            transition: all 0.2s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
            border-color: #cbd5e1;
        }

        .stat-icon {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }

        .stat-icon.green { background: #d1fae5; color: #059669; }
        .stat-icon.blue { background: #dbeafe; color: #2563eb; }
        .stat-icon.amber { background: #fef3c7; color: #d97706; }
        .stat-icon.purple { background: #ede9fe; color: #7c3aed; }

        .stat-meta h3 {
            font-size: 24px;
            font-weight: 800;
            color: var(--text-main);
            line-height: 1.2;
        }

        .stat-meta span {
            font-size: 12.5px;
            font-weight: 600;
            color: var(--text-muted);
        }

        /* Section Cards */
        .card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            padding: 26px 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 22px;
            padding-bottom: 16px;
            border-bottom: 1px solid #f1f5f9;
        }

        .card-header h2 {
            font-size: 18px;
            font-weight: 800;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-header .subtitle {
            font-size: 13px;
            color: var(--text-muted);
            font-weight: 500;
        }

        /* Class Selection Pills / Table */
        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        thead th {
            text-align: left;
            padding: 12px 16px;
            background: #f8fafc;
            color: #475569;
            font-weight: 700;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1.5px solid var(--border-color);
        }

        tbody td {
            padding: 16px;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            vertical-align: middle;
        }

        tbody tr {
            transition: background 0.15s ease;
        }

        tbody tr:hover {
            background: #f8fafc;
        }

        tbody tr.selected-row {
            background: #f0fdf4 !important;
            border-left: 3px solid #059669;
        }

        .code-pill {
            display: inline-block;
            padding: 4px 10px;
            background: #e0e7ff;
            color: #3730a3;
            border-radius: 6px;
            font-weight: 700;
            font-size: 12.5px;
        }

        .rating-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
            background: #fef3c7;
            color: #92400e;
        }

        .progress-container {
            width: 120px;
            background: #e2e8f0;
            border-radius: 10px;
            height: 8px;
            overflow: hidden;
            display: inline-block;
            vertical-align: middle;
            margin-right: 8px;
        }

        .progress-bar-inner {
            height: 100%;
            background: #059669;
            border-radius: 10px;
        }

        .btn-view-feedback {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 14px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
            text-decoration: none;
            background: #059669;
            color: #ffffff;
            transition: all 0.15s ease;
        }

        .btn-view-feedback:hover {
            background: #047857;
            box-shadow: 0 2px 6px rgba(5, 150, 105, 0.3);
        }

        .btn-view-feedback.active {
            background: #0f172a;
        }

        /* 9 Criteria Breakdown Section */
        .criteria-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
            margin-bottom: 24px;
        }

        .criteria-card {
            background: #f8fafc;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 18px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            transition: all 0.2s ease;
        }

        .criteria-card:hover {
            border-color: #cbd5e1;
            background: #ffffff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        .criteria-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }

        .criteria-tag {
            font-size: 11px;
            font-weight: 700;
            background: #e2e8f0;
            color: #475569;
            padding: 3px 8px;
            border-radius: 6px;
        }

        .criteria-score {
            font-size: 20px;
            font-weight: 800;
            color: #059669;
        }

        .criteria-title {
            font-size: 13px;
            font-weight: 600;
            color: #1e293b;
            line-height: 1.4;
            margin-bottom: 14px;
            min-height: 52px;
        }

        .criteria-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-excellent { background: #d1fae5; color: #065f46; padding: 3px 8px; border-radius: 10px; }
        .badge-good { background: #dbeafe; color: #1e40af; padding: 3px 8px; border-radius: 10px; }
        .badge-average { background: #fef3c7; color: #92400e; padding: 3px 8px; border-radius: 10px; }
        .badge-poor { background: #fee2e2; color: #991b1b; padding: 3px 8px; border-radius: 10px; }

        /* Charts Layout */
        .charts-row {
            display: grid;
            grid-template-columns: 1.2fr 0.8fr;
            gap: 24px;
            margin-bottom: 30px;
        }

        .chart-box {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 14px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
        }

        .chart-box h3 {
            font-size: 16px;
            font-weight: 800;
            color: var(--text-main);
            margin-bottom: 6px;
        }

        .chart-box p {
            font-size: 12.5px;
            color: var(--text-muted);
            margin-bottom: 18px;
        }

        .chart-wrapper {
            position: relative;
            height: 300px;
            width: 100%;
        }

        /* Student Comments & Teacher Reply Thread */
        .feedback-item {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 20px;
            transition: all 0.2s ease;
        }

        .feedback-item:hover {
            border-color: #cbd5e1;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.04);
        }

        .feedback-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }

        .student-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .student-avatar {
            width: 38px;
            height: 38px;
            background: #e2e8f0;
            color: #475569;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: 700;
        }

        .student-meta strong {
            font-size: 14px;
            color: var(--text-main);
            display: block;
        }

        .student-meta span {
            font-size: 12px;
            color: var(--text-muted);
        }

        .comment-text {
            font-size: 14.5px;
            color: #334155;
            line-height: 1.6;
            background: #f8fafc;
            padding: 16px 18px;
            border-radius: 10px;
            border-left: 4px solid #059669;
            margin-bottom: 16px;
        }

        /* Teacher Reply Stream */
        .replies-thread {
            margin-left: 30px;
            padding-left: 20px;
            border-left: 2px dashed #cbd5e1;
            margin-bottom: 16px;
        }

        .reply-card {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            border-radius: 10px;
            padding: 14px 18px;
            margin-bottom: 10px;
        }

        .reply-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 6px;
        }

        .reply-author {
            font-size: 13px;
            font-weight: 700;
            color: #065f46;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .reply-time {
            font-size: 11.5px;
            color: #64748b;
        }

        .reply-content {
            font-size: 13.5px;
            color: #1e293b;
            line-height: 1.5;
        }

        /* Reply Input Form */
        .reply-form-box {
            margin-left: 30px;
            background: #f8fafc;
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 16px;
        }

        .reply-form-box textarea {
            width: 100%;
            height: 75px;
            padding: 10px 14px;
            border: 1.5px solid #cbd5e1;
            border-radius: 8px;
            font-size: 13.5px;
            font-family: inherit;
            color: #0f172a;
            resize: vertical;
            outline: none;
            transition: all 0.15s ease;
        }

        .reply-form-box textarea:focus {
            border-color: #059669;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.15);
        }

        .reply-actions {
            display: flex;
            justify-content: flex-end;
            margin-top: 10px;
        }

        .btn-submit-reply {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 18px;
            background: #059669;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.15s ease;
        }

        .btn-submit-reply:hover {
            background: #047857;
            transform: translateY(-1px);
        }

        .empty-box {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-muted);
        }

        .empty-box .icon {
            font-size: 40px;
            margin-bottom: 10px;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 1024px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .criteria-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-row { grid-template-columns: 1fr; }
        }

        @media (max-width: 768px) {
            .sidebar { display: none; }
            .main { margin-left: 0; padding: 20px; }
            .stats-grid { grid-template-columns: 1fr; }
            .criteria-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="brand-icon">T</div>
            <div class="brand-text">
                <h2>Feedback Portal</h2>
                <span>Teacher Control Panel</span>
            </div>
        </div>

        <nav class="sidebar-nav">
            <span class="nav-label">Phân hệ Giảng viên</span>
            <a href="${pageContext.request.contextPath}/teacher/home" class="active">
                <span>📊</span> Tổng quan Dashboard
            </a>
            <a href="#classesSection">
                <span>📚</span> Danh sách Lớp phụ trách
            </a>
            <a href="#criteriaSection">
                <span>⭐</span> Điểm số 9 Tiêu chí
            </a>
            <a href="#chartsSection">
                <span>📈</span> Thống kê & Biểu đồ
            </a>
            <a href="#feedbackSection">
                <span>💬</span> Ý kiến & Trả lời sinh viên
            </a>

            <span class="nav-label" style="margin-top: 15px;">Hệ thống</span>
            <a href="${pageContext.request.contextPath}/logout" class="logout">
                <span>🚪</span> Đăng xuất
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main">
        <!-- Header -->
        <div class="header">
            <div class="header-title">
                <h1>Báo cáo & Thống kê Giảng dạy</h1>
                <p>Theo dõi kết quả đánh giá chất lượng từ sinh viên và giải đáp các ý kiến đóng góp</p>
            </div>
            <div class="user-badge">
                <div class="user-avatar">
                    ${not empty sessionScope.account.fullName ? sessionScope.account.fullName.substring(0,1) : 'T'}
                </div>
                <div class="user-info">
                    <span class="name">${sessionScope.account.fullName}</span>
                    <span class="role-tag">● Giảng viên bộ môn</span>
                </div>
            </div>
        </div>

        <!-- Flash Messages -->
        <c:if test="${not empty sessionScope.msgSuccess}">
            <div class="alert alert-success">
                <span>✅ ${sessionScope.msgSuccess}</span>
                <span style="cursor:pointer;" onclick="this.parentElement.style.display='none'">✕</span>
            </div>
            <c:remove var="msgSuccess" scope="session" />
        </c:if>
        <c:if test="${not empty sessionScope.msgError}">
            <div class="alert alert-error">
                <span>⚠️ ${sessionScope.msgError}</span>
                <span style="cursor:pointer;" onclick="this.parentElement.style.display='none'">✕</span>
            </div>
            <c:remove var="msgError" scope="session" />
        </c:if>

        <!-- Welcome Banner with Semester Filter -->
        <div class="welcome-card">
            <div class="welcome-content">
                <h2>Chào mừng Thầy/Cô ${sessionScope.account.fullName}!</h2>
                <p>Hệ thống tự động phân tích ý kiến phản hồi ẩn danh từ sinh viên, giúp thầy cô theo dõi sát sao mức độ hài lòng và không ngừng nâng cao chất lượng giảng dạy.</p>
            </div>

            <form action="${pageContext.request.contextPath}/teacher/home" method="GET" class="filter-controls">
                <label for="semesterSelect">Học kỳ:</label>
                <select id="semesterSelect" name="semesterId" class="filter-select" onchange="this.form.submit()">
                    <option value="0">Tất cả các học kỳ</option>
                    <c:forEach items="${semesterList}" var="sem">
                        <option value="${sem.semesterId}" ${sem.semesterId == currentSemesterId ? 'selected' : ''}>
                            ${sem.semesterName} (${sem.academicYear})
                        </option>
                    </c:forEach>
                    <c:if test="${empty semesterList}">
                        <option value="1" selected>Summer 2026</option>
                        <option value="2">Spring 2026</option>
                    </c:if>
                </select>
            </form>
        </div>

        <!-- KPI Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon green">📚</div>
                <div class="stat-meta">
                    <h3>${totalClasses}</h3>
                    <span>Lớp học phần phụ trách</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon blue">📝</div>
                <div class="stat-meta">
                    <h3>${totalFeedbacks}</h3>
                    <span>Lượt sinh viên đánh giá</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon amber">⭐</div>
                <div class="stat-meta">
                    <h3>${overallRating} <small style="font-size: 14px; color: #94a3b8;">/ 5.0</small></h3>
                    <span>Điểm đánh giá trung bình</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon purple">🎯</div>
                <div class="stat-meta">
                    <h3>${avgResponseRate}%</h3>
                    <span>Tỷ lệ phản hồi trung bình</span>
                </div>
            </div>
        </div>

        <!-- Section 1: Danh sách Lớp phụ trách -->
        <div class="card" id="classesSection">
            <div class="card-header">
                <div>
                    <h2>📚 Danh sách Lớp Học phần Đang phụ trách</h2>
                    <span class="subtitle">Bấm "Xem Feedback" để xem kết quả chi tiết từng lớp học</span>
                </div>
            </div>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Mã lớp</th>
                            <th>Môn học</th>
                            <th>Học kỳ</th>
                            <th>Sĩ số</th>
                            <th>Đã phản hồi</th>
                            <th>Tỷ lệ hoàn thành</th>
                            <th>Điểm TB</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${teacherClasses}" var="tc">
                            <tr class="${tc.classId == selectedClassId ? 'selected-row' : ''}">
                                <td><span class="code-pill">${tc.classCode}</span></td>
                                <td>
                                    <strong>[${tc.courseCode}]</strong> ${tc.courseName}
                                    <small style="color: #64748b; display: block;">${tc.credits} tín chỉ</small>
                                </td>
                                <td>${tc.semesterName}</td>
                                <td><strong>${tc.totalStudents}</strong> sinh viên</td>
                                <td><strong>${tc.feedbackCount}</strong> lượt</td>
                                <td>
                                    <div class="progress-container">
                                        <div class="progress-bar-inner" style="width: ${tc.responseRate}%;"></div>
                                    </div>
                                    <span style="font-size: 12.5px; font-weight: 700; color: #059669;">${tc.responseRate}%</span>
                                </td>
                                <td>
                                    <span class="rating-badge">★ ${tc.averageRating}</span>
                                </td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/teacher/home?classId=${tc.classId}&semesterId=${currentSemesterId}" 
                                       class="btn-view-feedback ${tc.classId == selectedClassId ? 'active' : ''}">
                                        ${tc.classId == selectedClassId ? '✓ Đang xem' : '🔍 Xem Feedback'}
                                    </a>
                                </td>
                            </tr>
                        </c:forEach>

                        <c:if test="${empty teacherClasses}">
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 30px; color: #64748b;">
                                    Không tìm thấy lớp học phần nào trong học kỳ đã chọn.
                                </td>
                            </tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Section 2: Điểm số 9 Tiêu chí Đánh giá của Lớp Đang Chọn -->
        <c:if test="${not empty currentClass}">
            <div class="card" id="criteriaSection">
                <div class="card-header">
                    <div>
                        <h2>⭐ Kết quả Đánh giá 9 Tiêu chí: <span style="color: #059669;">[${currentClass.classCode}] ${currentClass.courseName}</span></h2>
                        <span class="subtitle">Thang điểm từ 1.0 (Rất không hài lòng) đến 5.0 (Rất hài lòng)</span>
                    </div>
                    <span class="rating-badge" style="font-size: 14px; padding: 6px 14px;">
                        Điểm tổng kết: ★ ${currentClass.averageRating} / 5.0
                    </span>
                </div>

                <div class="criteria-grid">
                    <c:forEach items="${criteriaList}" var="crit">
                        <div class="criteria-card">
                            <div class="criteria-top">
                                <span class="criteria-tag">Câu ${crit.criteriaNumber}: ${crit.category}</span>
                                <span class="criteria-score">★ ${crit.averageScore}</span>
                            </div>
                            <div class="criteria-title">${crit.criteriaTitle}</div>
                            <div class="criteria-footer">
                                <div style="flex: 1; margin-right: 12px;">
                                    <div class="progress-container" style="width: 100%;">
                                        <div class="progress-bar-inner" style="width: ${crit.scorePercentage}%;"></div>
                                    </div>
                                </div>
                                <span class="${crit.badgeClass}">${crit.evaluationLevel}</span>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </div>

            <!-- Section 3: Thống kê & Biểu đồ Nâng cao (Chart.js) -->
            <div class="charts-row" id="chartsSection">
                <!-- Radar Chart for 9 Criteria -->
                <div class="chart-box">
                    <h3>📈 Biểu đồ Đa chiều 9 Tiêu chí Chất lượng</h3>
                    <p>Phân tích mức độ hoàn thiện các khía cạnh giảng dạy của lớp <strong>${currentClass.classCode}</strong></p>
                    <div class="chart-wrapper">
                        <canvas id="radarCriteriaChart"></canvas>
                    </div>
                </div>

                <!-- Comparison Bar Chart across Classes -->
                <div class="chart-box">
                    <h3>📊 So sánh Điểm số giữa các Lớp</h3>
                    <p>Tổng quan kết quả xếp hạng trung bình các lớp học phần phụ trách</p>
                    <div class="chart-wrapper">
                        <canvas id="barClassesChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Section 4: Danh sách Ý kiến Sinh viên & Trả lời Feedback -->
            <div class="card" id="feedbackSection">
                <div class="card-header">
                    <div>
                        <h2>💬 Ý kiến Đóng góp của Sinh viên & Trả lời Phản hồi</h2>
                        <span class="subtitle">Giảng viên có thể giải đáp, tiếp thu hoặc thông báo hướng điều chỉnh bài giảng cho sinh viên</span>
                    </div>
                    <span class="code-pill">${feedbackList.size()} ý kiến đóng góp</span>
                </div>

                <c:choose>
                    <c:when test="${not empty feedbackList}">
                        <c:forEach items="${feedbackList}" var="fb" varStatus="loop">
                            <div class="feedback-item">
                                <div class="feedback-header">
                                    <div class="student-info">
                                        <div class="student-avatar">👤</div>
                                        <div class="student-meta">
                                            <strong>${fb.studentName}</strong>
                                            <span>Khóa Summer 2026 • Lớp ${fb.classCode}</span>
                                        </div>
                                    </div>
                                    <span class="rating-badge">★ ${fb.averageScore} / 5.0</span>
                                </div>

                                <div class="comment-text">
                                    "${fb.comments}"
                                </div>

                                <!-- Existing Teacher Replies -->
                                <c:if test="${not empty fb.replies}">
                                    <div class="replies-thread">
                                        <c:forEach items="${fb.replies}" var="r">
                                            <div class="reply-card">
                                                <div class="reply-header">
                                                    <span class="reply-author">👨‍🏫 ${r.teacherName} (Giảng viên)</span>
                                                    <span class="reply-time"><fmt:formatDate value="${r.createdAt}" pattern="dd/MM/yyyy HH:mm" /></span>
                                                </div>
                                                <div class="reply-content">${r.replyContent}</div>
                                            </div>
                                        </c:forEach>
                                    </div>
                                </c:if>

                                <!-- Teacher Reply Input Form -->
                                <div class="reply-form-box">
                                    <form action="${pageContext.request.contextPath}/teacher/home" method="POST">
                                        <input type="hidden" name="action" value="reply">
                                        <input type="hidden" name="feedbackId" value="${fb.feedbackId}">
                                        <input type="hidden" name="classId" value="${currentClass.classId}">
                                        <textarea name="replyContent" placeholder="Nhập câu trả lời hoặc lời cảm ơn của Thầy/Cô gửi đến sinh viên..." required></textarea>
                                        <div class="reply-actions">
                                            <button type="submit" class="btn-submit-reply">
                                                ✉️ Gửi câu trả lời
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <div class="empty-box">
                            <div class="icon">💬</div>
                            <h3>Chưa có ý kiến nhận xét nào cho lớp này</h3>
                            <p>Khi sinh viên nộp bài khảo sát ý kiến, các góp ý và nhận xét sẽ hiển thị tại đây.</p>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </c:if>
    </main>

    <!-- Chart.js Visualization Scripts -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // 1. Dữ liệu Radar Chart cho 9 tiêu chí
            const criteriaLabels = [
                'Học liệu', 'Nội dung', 'Phương pháp', 
                'Tác phong', 'Tương tác', 'Đánh giá', 
                'Hỗ trợ', 'Môi trường', 'Hài lòng chung'
            ];
            
            const criteriaScores = [
                <c:forEach items="${criteriaList}" var="c" varStatus="loop">
                    ${c.averageScore}${!loop.last ? ',' : ''}
                </c:forEach>
            ];

            const radarCanvas = document.getElementById('radarCriteriaChart');
            if (radarCanvas) {
                new Chart(radarCanvas, {
                    type: 'radar',
                    data: {
                        labels: criteriaLabels,
                        datasets: [{
                            label: 'Điểm trung bình (Thang 5.0)',
                            data: criteriaScores.length > 0 ? criteriaScores : [4.8, 4.7, 4.9, 4.9, 4.8, 4.7, 4.6, 4.8, 4.8],
                            backgroundColor: 'rgba(5, 150, 105, 0.25)',
                            borderColor: '#059669',
                            borderWidth: 2,
                            pointBackgroundColor: '#059669',
                            pointBorderColor: '#fff',
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: '#059669'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            r: {
                                angleLines: { color: 'rgba(0, 0, 0, 0.08)' },
                                grid: { color: 'rgba(0, 0, 0, 0.08)' },
                                suggestedMin: 3.0,
                                suggestedMax: 5.0,
                                ticks: { stepSize: 0.5, font: { size: 10 } }
                            }
                        },
                        plugins: {
                            legend: { position: 'bottom', labels: { font: { family: 'Plus Jakarta Sans', weight: '600' } } }
                        }
                    }
                });
            }

            // 2. Dữ liệu Bar Chart so sánh các lớp
            const classLabels = [
                <c:forEach items="${teacherClasses}" var="tc" varStatus="loop">
                    '${tc.classCode}'${!loop.last ? ',' : ''}
                </c:forEach>
            ];

            const classRatings = [
                <c:forEach items="${teacherClasses}" var="tc" varStatus="loop">
                    ${tc.averageRating}${!loop.last ? ',' : ''}
                </c:forEach>
            ];

            const barCanvas = document.getElementById('barClassesChart');
            if (barCanvas) {
                new Chart(barCanvas, {
                    type: 'bar',
                    data: {
                        labels: classLabels.length > 0 ? classLabels : ['SE1801-PRJ', 'SE1802-DBI', 'SE1803-PRO'],
                        datasets: [{
                            label: 'Điểm đánh giá TB',
                            data: classRatings.length > 0 ? classRatings : [4.8, 4.9, 4.6],
                            backgroundColor: [
                                'rgba(5, 150, 105, 0.85)',
                                'rgba(37, 99, 235, 0.85)',
                                'rgba(217, 119, 6, 0.85)',
                                'rgba(124, 58, 237, 0.85)'
                            ],
                            borderRadius: 8,
                            borderSkipped: false
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                suggestedMin: 3.5,
                                suggestedMax: 5.0,
                                ticks: { stepSize: 0.5 }
                            },
                            x: {
                                grid: { display: false }
                            }
                        },
                        plugins: {
                            legend: { display: false }
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>