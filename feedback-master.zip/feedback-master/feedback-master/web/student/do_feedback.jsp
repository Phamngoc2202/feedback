<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bài làm Đánh giá Giảng viên - Student Feedback</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
            min-height: 100vh;
            padding-bottom: 90px;
        }

        /* Top Navigation Bar */
        .top-navbar {
            background: #0f172a;
            color: #ffffff;
            padding: 14px 28px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: #ffffff;
        }

        .brand-icon {
            width: 34px;
            height: 34px;
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 16px;
        }

        .brand-text h1 {
            font-size: 16px;
            font-weight: 700;
            letter-spacing: 0.3px;
        }

        .brand-text span {
            font-size: 11px;
            color: #94a3b8;
        }

        .navbar-user {
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 14px;
        }

        .user-pill {
            background: rgba(255, 255, 255, 0.1);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
        }

        .btn-nav-exit {
            color: #cbd5e1;
            text-decoration: none;
            font-size: 13px;
            padding: 6px 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 6px;
            transition: all 0.15s ease;
        }

        .btn-nav-exit:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
        }

        /* Container */
        .container {
            max-width: 920px;
            margin: 28px auto;
            padding: 0 20px;
        }

        /* Survey Info Banner */
        .survey-header-card {
            background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 60%, #2563eb 100%);
            border-radius: 12px;
            color: #ffffff;
            padding: 28px 32px;
            box-shadow: 0 10px 25px -5px rgba(30, 58, 138, 0.25);
            margin-bottom: 24px;
        }

        .survey-badge-row {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 12px;
        }

        .badge-active {
            background: #10b981;
            color: #ffffff;
            font-size: 12px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .badge-semester {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            font-size: 12px;
            font-weight: 500;
            padding: 4px 10px;
            border-radius: 12px;
        }

        .survey-title {
            font-size: 24px;
            font-weight: 700;
            line-height: 1.3;
            margin-bottom: 12px;
        }

        .survey-desc {
            font-size: 14px;
            color: #e2e8f0;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        /* Target Selection (Course & Teacher) */
        .target-selection-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            background: rgba(255, 255, 255, 0.12);
            border-radius: 8px;
            padding: 16px 20px;
            backdrop-filter: blur(8px);
        }

        .target-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .target-group label {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #bfdbfe;
        }

        .target-group select {
            background: #ffffff;
            color: #0f172a;
            border: none;
            padding: 10px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            outline: none;
            cursor: pointer;
        }

        /* Progress Card */
        .progress-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 16px 22px;
            margin-bottom: 24px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .progress-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            font-weight: 600;
        }

        .progress-meta .count-text {
            color: #475569;
        }

        .progress-meta .percent-text {
            color: #1e40af;
        }

        .progress-bar-bg {
            width: 100%;
            height: 10px;
            background: #e2e8f0;
            border-radius: 6px;
            overflow: hidden;
        }

        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #3b82f6, #10b981);
            width: 0%;
            border-radius: 6px;
            transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* Section Card */
        .section-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 24px 28px;
            margin-bottom: 20px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 12px;
            border-bottom: 1.5px solid #f1f5f9;
            padding-bottom: 14px;
            margin-bottom: 20px;
        }

        .section-number {
            width: 28px;
            height: 28px;
            background: #dbeafe;
            color: #1e40af;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
        }

        .section-header h2 {
            font-size: 17px;
            font-weight: 700;
            color: #0f172a;
        }

        /* Question Item */
        .question-item {
            margin-bottom: 24px;
            padding-bottom: 22px;
            border-bottom: 1px dashed #e2e8f0;
        }

        .question-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .question-title {
            font-size: 15px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 14px;
            line-height: 1.5;
            display: flex;
            align-items: flex-start;
            gap: 8px;
        }

        .question-tag {
            color: #64748b;
            font-size: 14px;
            font-weight: 600;
        }

        /* Scale / Options */
        .rating-options {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
        }

        .rating-option {
            position: relative;
        }

        .rating-option input[type="radio"] {
            position: absolute;
            opacity: 0;
            width: 0;
            height: 0;
        }

        .rating-label {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 12px 6px;
            border: 1.5px solid #cbd5e1;
            border-radius: 8px;
            background: #ffffff;
            cursor: pointer;
            text-align: center;
            transition: all 0.15s ease;
            user-select: none;
            height: 100%;
        }

        .rating-icon {
            font-size: 20px;
            margin-bottom: 4px;
        }

        .rating-score {
            font-size: 13px;
            font-weight: 700;
            color: #334155;
            margin-bottom: 2px;
        }

        .rating-text {
            font-size: 11px;
            color: #64748b;
            line-height: 1.2;
        }

        .rating-option:hover .rating-label {
            border-color: #3b82f6;
            background: #f8fafc;
        }

        .rating-option input[type="radio"]:checked + .rating-label {
            border-color: #1e40af;
            background: #eff6ff;
            box-shadow: 0 0 0 2px rgba(30, 64, 175, 0.2);
        }

        .rating-option input[type="radio"]:checked + .rating-label .rating-score {
            color: #1e40af;
        }

        /* Comment Textarea */
        .comment-area-wrapper {
            margin-top: 10px;
        }

        .comment-textarea {
            width: 100%;
            height: 110px;
            padding: 12px 16px;
            border: 1.5px solid #cbd5e1;
            border-radius: 8px;
            font-size: 14px;
            color: #1e293b;
            font-family: inherit;
            resize: vertical;
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
        }

        .comment-textarea:focus {
            outline: none;
            border-color: #1e40af;
            box-shadow: 0 0 0 3px rgba(30, 64, 175, 0.15);
        }

        .char-counter {
            text-align: right;
            font-size: 12px;
            color: #94a3b8;
            margin-top: 6px;
        }

        /* Sticky Action Footer */
        .bottom-action-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: #ffffff;
            border-top: 1px solid #e2e8f0;
            padding: 14px 28px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.06);
            z-index: 100;
        }

        .action-container {
            max-width: 920px;
            margin: 0 auto;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 18px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            color: #475569;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            background: #ffffff;
            transition: all 0.15s ease;
        }

        .btn-back:hover {
            background: #f8fafc;
            color: #1e293b;
        }

        .btn-submit {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 28px;
            background: #1e40af;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
            box-shadow: 0 2px 6px rgba(30, 64, 175, 0.3);
        }

        .btn-submit:hover {
            background: #1e3a8a;
            box-shadow: 0 4px 10px rgba(30, 64, 175, 0.4);
            transform: translateY(-1px);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        @media (max-width: 768px) {
            .target-selection-grid {
                grid-template-columns: 1fr;
            }
            .rating-options {
                grid-template-columns: repeat(5, 1fr);
                gap: 6px;
            }
            .rating-label {
                padding: 8px 2px;
            }
            .rating-text {
                display: none;
            }
            .section-card {
                padding: 18px 16px;
            }
        }
    </style>
</head>
<body>

    <!-- Top Navigation Header -->
    <header class="top-navbar">
        <a href="${pageContext.request.contextPath}/student/home.jsp" class="navbar-brand">
            <div class="brand-icon">F</div>
            <div class="brand-text">
                <h1>Feedback System</h1>
                <span>Student Evaluation Portal</span>
            </div>
        </a>

        <div class="navbar-user">
            <div class="user-pill">
                Sinh viên: <strong>${sessionScope.account.fullName}</strong>
            </div>
            <a href="${pageContext.request.contextPath}/student/home.jsp" class="btn-nav-exit">Thoát bài làm</a>
        </div>
    </header>

    <div class="container">
        <!-- Survey Meta Header -->
        <div class="survey-header-card">
            <div class="survey-badge-row">
                <span class="badge-active">● Đang mở khảo sát</span>
                <span class="badge-semester">${not empty currentForm ? currentForm.semesterName : 'Học kỳ Summer 2026'}</span>
            </div>
            <h1 class="survey-title">${not empty currentForm ? currentForm.title : 'Khảo sát Đánh giá Ý kiến Sinh viên về Hoạt động Giảng dạy'}</h1>
            <p class="survey-desc">
                Ý kiến đóng góp ẩn danh của bạn là cơ sở quan trọng giúp nâng cao chất lượng giảng dạy, cơ sở vật chất và đổi mới phương pháp đào tạo của nhà trường.
            </p>

            <form id="feedbackForm" action="${pageContext.request.contextPath}/student/feedback" method="POST">
                <input type="hidden" name="formId" value="${not empty currentForm ? currentForm.formId : '1'}">

                <!-- Target Course & Teacher Selection -->
                <div class="target-selection-grid">
                    <div class="target-group">
                        <label for="courseSelect">1. Chọn Môn học đánh giá *</label>
                        <select id="courseSelect" name="courseId" required>
                            <c:forEach items="${courseList}" var="c">
                                <option value="${c.courseId}">[${c.courseCode}] ${c.courseName} (${c.credits} tín chỉ)</option>
                            </c:forEach>
                            <c:if test="${empty courseList}">
                                <option value="1">[PRJ301] Java Web Application Development</option>
                                <option value="2">[DBI202] Database Systems</option>
                                <option value="3">[PRO192] Object-Oriented Programming</option>
                            </c:if>
                        </select>
                    </div>

                    <div class="target-group">
                        <label for="teacherSelect">2. Chọn Giảng viên phụ trách *</label>
                        <select id="teacherSelect" name="teacherId" required>
                            <c:forEach items="${teacherList}" var="t">
                                <option value="${t.userId}">ThS. ${t.fullName} (${t.email})</option>
                            </c:forEach>
                            <c:if test="${empty teacherList}">
                                <option value="1">ThS. Nguyễn Văn Thầy (teacher1@fpt.edu.vn)</option>
                                <option value="2">TS. Trần Thị Cô (teacher2@fpt.edu.vn)</option>
                            </c:if>
                        </select>
                    </div>
                </div>
        </div>

        <!-- Progress Tracker -->
        <div class="progress-card">
            <div class="progress-meta">
                <span class="count-text" id="progressCount">Tiến độ: Đã trả lời 0 / 9 câu hỏi</span>
                <span class="percent-text" id="progressPercent">0%</span>
            </div>
            <div class="progress-bar-bg">
                <div class="progress-bar-fill" id="progressBar"></div>
            </div>
        </div>

        <!-- Section 1: Chuẩn bị & Học liệu -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-number">1</div>
                <h2>Chuẩn bị Môn học & Học liệu</h2>
            </div>

            <!-- Question 1 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 1:</span>
                    <span>Giảng viên cung cấp đề cương, tài liệu tham khảo và tiêu chí đánh giá môn học rõ ràng, đầy đủ ngay từ đầu kỳ.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option">
                        <input type="radio" name="q1" value="1" onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">😡</span>
                            <span class="rating-score">1</span>
                            <span class="rating-text">Rất không hài lòng</span>
                        </div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q1" value="2" onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">🙁</span>
                            <span class="rating-score">2</span>
                            <span class="rating-text">Không hài lòng</span>
                        </div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q1" value="3" onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">😐</span>
                            <span class="rating-score">3</span>
                            <span class="rating-text">Bình thường</span>
                        </div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q1" value="4" onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">🙂</span>
                            <span class="rating-score">4</span>
                            <span class="rating-text">Hài lòng</span>
                        </div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q1" value="5" checked onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">🌟</span>
                            <span class="rating-score">5</span>
                            <span class="rating-text">Rất hài lòng</span>
                        </div>
                    </label>
                </div>
            </div>

            <!-- Question 2 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 2:</span>
                    <span>Nội dung bài giảng bám sát thực tế, có tính cập nhật và liên hệ ứng dụng thực tiễn cao.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option">
                        <input type="radio" name="q2" value="1" onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">😡</span>
                            <span class="rating-score">1</span>
                            <span class="rating-text">Rất không hài lòng</span>
                        </div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q2" value="2" onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">🙁</span>
                            <span class="rating-score">2</span>
                            <span class="rating-text">Không hài lòng</span>
                        </div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q2" value="3" onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">😐</span>
                            <span class="rating-score">3</span>
                            <span class="rating-text">Bình thường</span>
                        </div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q2" value="4" onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">🙂</span>
                            <span class="rating-score">4</span>
                            <span class="rating-text">Hài lòng</span>
                        </div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q2" value="5" checked onchange="updateProgress()">
                        <div class="rating-label">
                            <span class="rating-icon">🌟</span>
                            <span class="rating-score">5</span>
                            <span class="rating-text">Rất hài lòng</span>
                        </div>
                    </label>
                </div>
            </div>
        </div>

        <!-- Section 2: Phương pháp giảng dạy -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-number">2</div>
                <h2>Phương pháp Giảng dạy & Tác phong Sư phạm</h2>
            </div>

            <!-- Question 3 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 3:</span>
                    <span>Giảng viên truyền đạt kiến thức dễ hiểu, mạch lạc và có ví dụ minh họa sinh động.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option">
                        <input type="radio" name="q3" value="1" onchange="updateProgress()">
                        <div class="rating-label"><span class="rating-icon">😡</span><span class="rating-score">1</span><span class="rating-text">Rất không hài lòng</span></div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q3" value="2" onchange="updateProgress()">
                        <div class="rating-label"><span class="rating-icon">🙁</span><span class="rating-score">2</span><span class="rating-text">Không hài lòng</span></div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q3" value="3" onchange="updateProgress()">
                        <div class="rating-label"><span class="rating-icon">😐</span><span class="rating-score">3</span><span class="rating-text">Bình thường</span></div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q3" value="4" onchange="updateProgress()">
                        <div class="rating-label"><span class="rating-icon">🙂</span><span class="rating-score">4</span><span class="rating-text">Hài lòng</span></div>
                    </label>
                    <label class="rating-option">
                        <input type="radio" name="q3" value="5" checked onchange="updateProgress()">
                        <div class="rating-label"><span class="rating-icon">🌟</span><span class="rating-score">5</span><span class="rating-text">Rất hài lòng</span></div>
                    </label>
                </div>
            </div>

            <!-- Question 4 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 4:</span>
                    <span>Sử dụng hiệu quả các công cụ hỗ trợ giảng dạy, bài tập thực hành trên lớp.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option"><input type="radio" name="q4" value="1" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😡</span><span class="rating-score">1</span><span class="rating-text">Rất không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q4" value="2" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙁</span><span class="rating-score">2</span><span class="rating-text">Không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q4" value="3" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😐</span><span class="rating-score">3</span><span class="rating-text">Bình thường</span></div></label>
                    <label class="rating-option"><input type="radio" name="q4" value="4" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙂</span><span class="rating-score">4</span><span class="rating-text">Hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q4" value="5" checked onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🌟</span><span class="rating-score">5</span><span class="rating-text">Rất hài lòng</span></div></label>
                </div>
            </div>

            <!-- Question 5 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 5:</span>
                    <span>Giảng viên luôn đúng giờ, tuân thủ kỷ luật giảng dạy và đảm bảo thời lượng buổi học.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option"><input type="radio" name="q5" value="1" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😡</span><span class="rating-score">1</span><span class="rating-text">Rất không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q5" value="2" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙁</span><span class="rating-score">2</span><span class="rating-text">Không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q5" value="3" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😐</span><span class="rating-score">3</span><span class="rating-text">Bình thường</span></div></label>
                    <label class="rating-option"><input type="radio" name="q5" value="4" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙂</span><span class="rating-score">4</span><span class="rating-text">Hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q5" value="5" checked onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🌟</span><span class="rating-score">5</span><span class="rating-text">Rất hài lòng</span></div></label>
                </div>
            </div>
        </div>

        <!-- Section 3: Tương tác & Hỗ trợ sinh viên -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-number">3</div>
                <h2>Tương tác & Hỗ trợ Sinh viên</h2>
            </div>

            <!-- Question 6 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 6:</span>
                    <span>Giảng viên nhiệt tình giải đáp thắc mắc của sinh viên trong và ngoài giờ học.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option"><input type="radio" name="q6" value="1" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😡</span><span class="rating-score">1</span><span class="rating-text">Rất không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q6" value="2" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙁</span><span class="rating-score">2</span><span class="rating-text">Không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q6" value="3" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😐</span><span class="rating-score">3</span><span class="rating-text">Bình thường</span></div></label>
                    <label class="rating-option"><input type="radio" name="q6" value="4" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙂</span><span class="rating-score">4</span><span class="rating-text">Hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q6" value="5" checked onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🌟</span><span class="rating-score">5</span><span class="rating-text">Rất hài lòng</span></div></label>
                </div>
            </div>

            <!-- Question 7 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 7:</span>
                    <span>Khuyến khích thảo luận, phản biện và tạo không khí học tập tích cực trong lớp.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option"><input type="radio" name="q7" value="1" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😡</span><span class="rating-score">1</span><span class="rating-text">Rất không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q7" value="2" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙁</span><span class="rating-score">2</span><span class="rating-text">Không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q7" value="3" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😐</span><span class="rating-score">3</span><span class="rating-text">Bình thường</span></div></label>
                    <label class="rating-option"><input type="radio" name="q7" value="4" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙂</span><span class="rating-score">4</span><span class="rating-text">Hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q7" value="5" checked onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🌟</span><span class="rating-score">5</span><span class="rating-text">Rất hài lòng</span></div></label>
                </div>
            </div>
        </div>

        <!-- Section 4: Đánh giá & Chấm điểm -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-number">4</div>
                <h2>Đánh giá & Chấm điểm</h2>
            </div>

            <!-- Question 8 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 8:</span>
                    <span>Tiêu chí chấm điểm, nhận xét bài tập và phản hồi kết quả thi công bằng, khách quan và minh bạch.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option"><input type="radio" name="q8" value="1" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😡</span><span class="rating-score">1</span><span class="rating-text">Rất không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q8" value="2" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙁</span><span class="rating-score">2</span><span class="rating-text">Không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q8" value="3" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😐</span><span class="rating-score">3</span><span class="rating-text">Bình thường</span></div></label>
                    <label class="rating-option"><input type="radio" name="q8" value="4" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙂</span><span class="rating-score">4</span><span class="rating-text">Hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q8" value="5" checked onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🌟</span><span class="rating-score">5</span><span class="rating-text">Rất hài lòng</span></div></label>
                </div>
            </div>
        </div>

        <!-- Section 5: Đánh giá tổng quan & Ý kiến đóng góp -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-number">5</div>
                <h2>Đánh giá Tổng quan & Ý kiến Đóng góp</h2>
            </div>

            <!-- Question 9 -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Câu 9:</span>
                    <span>Mức độ hài lòng chung của bạn đối với giảng viên và môn học này trong suốt học kỳ.</span>
                </div>
                <div class="rating-options">
                    <label class="rating-option"><input type="radio" name="q9" value="1" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😡</span><span class="rating-score">1</span><span class="rating-text">Rất không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q9" value="2" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙁</span><span class="rating-score">2</span><span class="rating-text">Không hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q9" value="3" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">😐</span><span class="rating-score">3</span><span class="rating-text">Bình thường</span></div></label>
                    <label class="rating-option"><input type="radio" name="q9" value="4" onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🙂</span><span class="rating-score">4</span><span class="rating-text">Hài lòng</span></div></label>
                    <label class="rating-option"><input type="radio" name="q9" value="5" checked onchange="updateProgress()"><div class="rating-label"><span class="rating-icon">🌟</span><span class="rating-score">5</span><span class="rating-text">Rất hài lòng</span></div></label>
                </div>
            </div>

            <!-- Question 10 / Open feedback -->
            <div class="question-item">
                <div class="question-title">
                    <span class="question-tag">Ý kiến thêm:</span>
                    <span>Nhận xét, góp ý hoặc đề xuất cải thiện dành cho giảng viên / bộ môn (Không bắt buộc):</span>
                </div>
                <div class="comment-area-wrapper">
                    <textarea class="comment-textarea" name="comments" maxlength="500" placeholder="Ví dụ: Thầy/Cô giảng dạy rất nhiệt tình và tận tâm. Hy vọng có thêm nhiều bài tập thực hành tình huống thực tế hơn..." oninput="updateCharCount(this)"></textarea>
                    <div class="char-counter"><span id="charCount">0</span>/500 ký tự</div>
                </div>
            </div>
        </div>

        <!-- Sticky Action Footer Bar -->
        <footer class="bottom-action-bar">
            <div class="action-container">
                <a href="${pageContext.request.contextPath}/student/home.jsp" class="btn-back">
                    ← Hủy & Quay lại
                </a>
                <button type="submit" class="btn-submit" onclick="return confirmSubmit()">
                    <span>✓ Nộp bài Đánh giá</span>
                </button>
            </div>
        </footer>
        </form>
    </div>

    <script>
        function updateProgress() {
            const totalQuestions = 9;
            let answered = 0;
            for (let i = 1; i <= totalQuestions; i++) {
                const checked = document.querySelector('input[name="q' + i + '"]:checked');
                if (checked) {
                    answered++;
                }
            }
            const percentage = Math.round((answered / totalQuestions) * 100);
            document.getElementById('progressBar').style.width = percentage + '%';
            document.getElementById('progressPercent').innerText = percentage + '%';
            document.getElementById('progressCount').innerText = 'Tiến độ: Đã trả lời ' + answered + ' / ' + totalQuestions + ' câu hỏi';
        }

        function updateCharCount(el) {
            document.getElementById('charCount').innerText = el.value.length;
        }

        function confirmSubmit() {
            return confirm('Bạn có chắc chắn muốn nộp bài đánh giá này? Ý kiến của bạn sẽ được gửi ẩn danh và ghi nhận vào hệ thống.');
        }

        // Initialize progress on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateProgress();
        });
    </script>
</body>
</html>
