<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nộp bài Thành công - Feedback System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #f8fafc;
            color: #1e293b;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px 20px;
        }

        .success-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            max-width: 620px;
            width: 100%;
            padding: 40px;
            text-align: center;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
        }

        .success-icon-wrapper {
            width: 72px;
            height: 72px;
            background: #d1fae5;
            color: #059669;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            font-weight: bold;
            margin: 0 auto 20px;
            box-shadow: 0 0 0 8px #ecfdf5;
        }

        .success-title {
            font-size: 26px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 8px;
        }

        .success-subtitle {
            font-size: 15px;
            color: #64748b;
            line-height: 1.5;
            margin-bottom: 28px;
        }

        /* Receipt Box */
        .receipt-box {
            background: #f8fafc;
            border: 1.5px solid #e2e8f0;
            border-radius: 12px;
            padding: 24px;
            text-align: left;
            margin-bottom: 28px;
        }

        .receipt-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 12px;
            margin-bottom: 16px;
        }

        .receipt-title {
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #475569;
        }

        .receipt-code {
            font-size: 13px;
            font-weight: 700;
            color: #1e40af;
            background: #dbeafe;
            padding: 4px 10px;
            border-radius: 6px;
        }

        .receipt-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
            font-size: 14px;
        }

        .receipt-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
        }

        .receipt-label {
            color: #64748b;
            min-width: 140px;
        }

        .receipt-value {
            color: #0f172a;
            font-weight: 600;
            text-align: right;
        }

        .score-highlight {
            color: #d97706;
            font-size: 16px;
            font-weight: 700;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-primary {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            background: #1e40af;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.15s ease;
        }

        .btn-primary:hover {
            background: #1e3a8a;
            transform: translateY(-1px);
        }

        .btn-secondary {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: #ffffff;
            color: #334155;
            border: 1.5px solid #cbd5e1;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.15s ease;
        }

        .btn-secondary:hover {
            background: #f1f5f9;
            color: #0f172a;
        }

        @media (max-width: 600px) {
            .success-card {
                padding: 24px 18px;
            }
            .action-buttons {
                flex-direction: column;
            }
            .btn-primary, .btn-secondary {
                width: 100%;
                justify-content: center;
            }
            .receipt-row {
                flex-direction: column;
                gap: 2px;
            }
            .receipt-value {
                text-align: left;
            }
        }
    </style>
</head>
<body>

    <div class="success-card">
        <div class="success-icon-wrapper">✓</div>
        <h1 class="success-title">Nộp bài Đánh giá Thành công!</h1>
        <p class="success-subtitle">
            Cảm ơn bạn đã hoàn thành bài khảo sát. Ý kiến đánh giá của bạn đã được ghi nhận ẩn danh vào cơ sở dữ liệu hệ thống.
        </p>

        <!-- Digital Receipt Info -->
        <div class="receipt-box">
            <div class="receipt-header">
                <span class="receipt-title">Biên nhận Bài làm Đánh giá</span>
                <span class="receipt-code">Mã: ${not empty submission.submissionId ? submission.submissionId : 'FB738291'}</span>
            </div>

            <div class="receipt-list">
                <div class="receipt-row">
                    <span class="receipt-label">Đợt khảo sát:</span>
                    <span class="receipt-value">${not empty submission.formTitle ? submission.formTitle : 'Khảo sát ý kiến sinh viên'}</span>
                </div>
                <div class="receipt-row">
                    <span class="receipt-label">Học kỳ:</span>
                    <span class="receipt-value">${not empty submission.semesterName ? submission.semesterName : 'Summer 2026'}</span>
                </div>
                <div class="receipt-row">
                    <span class="receipt-label">Môn học đã đánh giá:</span>
                    <span class="receipt-value">[${submission.courseCode}] ${submission.courseName}</span>
                </div>
                <div class="receipt-row">
                    <span class="receipt-label">Giảng viên phụ trách:</span>
                    <span class="receipt-value">ThS. ${submission.teacherName}</span>
                </div>
                <div class="receipt-row">
                    <span class="receipt-label">Điểm đánh giá TB:</span>
                    <span class="receipt-value score-highlight">★ ${submission.averageScore} / 5.0</span>
                </div>
                <div class="receipt-row">
                    <span class="receipt-label">Thời gian nộp:</span>
                    <span class="receipt-value">${submission.submittedTime}</span>
                </div>
                <c:if test="${not empty submission.comments && submission.comments != 'Không có ý kiến thêm.'}">
                    <div class="receipt-row">
                        <span class="receipt-label">Ý kiến đóng góp:</span>
                        <span class="receipt-value" style="font-style: italic; font-weight: normal; max-width: 320px;">"${submission.comments}"</span>
                    </div>
                </c:if>
            </div>
        </div>

        <div class="action-buttons">
            <a href="${pageContext.request.contextPath}/student/home.jsp" class="btn-primary">
                🏠 Về Trang chủ
            </a>
            <a href="${pageContext.request.contextPath}/student/feedback?action=history" class="btn-secondary">
                📋 Xem Lịch sử bài nộp
            </a>
            <a href="${pageContext.request.contextPath}/student/feedback?action=do" class="btn-secondary">
                ✍️ Đánh giá môn khác
            </a>
        </div>
    </div>

</body>
</html>
