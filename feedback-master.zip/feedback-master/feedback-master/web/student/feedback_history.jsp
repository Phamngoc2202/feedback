<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lịch sử Đánh giá - Student Feedback</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #f0f2f5;
            color: #1f2937;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            background: #111827;
            color: #e5e7eb;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            display: flex;
            flex-direction: column;
            border-right: 1px solid #1f2937;
        }

        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid #1f2937;
        }

        .sidebar-header h2 {
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 0.3px;
            color: #f9fafb;
        }

        .sidebar-header span {
            display: block;
            font-size: 12px;
            color: #9ca3af;
            margin-top: 4px;
        }

        .sidebar-nav {
            flex: 1;
            padding: 16px 12px;
            display: flex;
            flex-direction: column;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 14px;
            color: #d1d5db;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 4px;
            transition: background 0.15s ease, color 0.15s ease;
        }

        .sidebar-nav a:hover {
            background: #1f2937;
            color: #f9fafb;
        }

        .sidebar-nav a.active {
            background: #1e40af;
            color: #ffffff;
        }

        .sidebar-nav a.logout {
            margin-top: auto;
            color: #fca5a5;
        }

        .sidebar-nav a.logout:hover {
            background: #7f1d1d;
            color: #fee2e2;
        }

        /* Main Content */
        .main {
            margin-left: 240px;
            flex: 1;
            padding: 28px 32px;
            max-width: 1200px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .header h1 {
            font-size: 22px;
            font-weight: 600;
            color: #111827;
        }

        .user-badge {
            font-size: 13px;
            color: #4b5563;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            padding: 6px 14px;
            border-radius: 20px;
        }

        .user-badge strong {
            color: #1e40af;
            font-weight: 600;
        }

        /* Card */
        .card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 24px 28px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            margin-bottom: 24px;
        }

        .card h2 {
            font-size: 16px;
            font-weight: 600;
            color: #111827;
            margin-bottom: 18px;
        }

        /* Table */
        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        thead th {
            text-align: left;
            padding: 12px 14px;
            background: #f9fafb;
            color: #4b5563;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            border-bottom: 1px solid #e5e7eb;
        }

        tbody td {
            padding: 14px;
            border-bottom: 1px solid #f3f4f6;
            color: #374151;
            vertical-align: middle;
        }

        tbody tr:hover {
            background: #f9fafb;
        }

        .code-badge {
            background: #e0e7ff;
            color: #3730a3;
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
        }

        .score-badge {
            background: #fef3c7;
            color: #92400e;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .status-badge {
            background: #d1fae5;
            color: #065f46;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 48px 20px;
            color: #64748b;
        }

        .empty-icon {
            font-size: 48px;
            margin-bottom: 12px;
        }

        .empty-state h3 {
            font-size: 17px;
            font-weight: 600;
            color: #334155;
            margin-bottom: 6px;
        }

        .empty-state p {
            font-size: 14px;
            margin-bottom: 20px;
        }

        .btn-start {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #1e40af;
            color: #ffffff;
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.15s ease;
        }

        .btn-start:hover {
            background: #1e3a8a;
        }

        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }
            .main {
                margin-left: 0;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>Feedback System</h2>
            <span>Student Portal</span>
        </div>
        <nav class="sidebar-nav">
            <a href="${pageContext.request.contextPath}/student/home.jsp">Dashboard</a>
            <a href="${pageContext.request.contextPath}/student/feedback?action=do">Làm bài Đánh giá</a>
            <a href="${pageContext.request.contextPath}/student/feedback?action=history" class="active">Lịch sử Bài làm</a>
            <a href="${pageContext.request.contextPath}/logout" class="logout">Đăng xuất</a>
        </nav>
    </aside>

    <main class="main">
        <div class="header">
            <h1>Lịch sử Bài làm Đánh giá</h1>
            <div class="user-badge">
                Sinh viên: <strong>${sessionScope.account.fullName}</strong>
            </div>
        </div>

        <div class="card">
            <h2>Danh sách bài đánh giá đã nộp</h2>

            <c:choose>
                <c:when test="${not empty historyList}">
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Mã bài nộp</th>
                                    <th>Đợt khảo sát</th>
                                    <th>Môn học</th>
                                    <th>Giảng viên</th>
                                    <th>Điểm TB</th>
                                    <th>Thời gian nộp</th>
                                    <th>Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach items="${historyList}" var="item">
                                    <tr>
                                        <td><span class="code-badge">${item.submissionId}</span></td>
                                        <td><strong>${item.formTitle}</strong> (${item.semesterName})</td>
                                        <td>[${item.courseCode}] ${item.courseName}</td>
                                        <td>ThS. ${item.teacherName}</td>
                                        <td><span class="score-badge">★ ${item.averageScore}</span></td>
                                        <td style="color: #6b7280; font-size: 13px;">${item.submittedTime}</td>
                                        <td><span class="status-badge">✓ Đã ghi nhận</span></td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </c:when>
                <c:otherwise>
                    <div class="empty-state">
                        <div class="empty-icon">📝</div>
                        <h3>Chưa có bài đánh giá nào được nộp</h3>
                        <p>Bạn chưa thực hiện bài khảo sát đánh giá nào trong phiên làm việc này.</p>
                        <a href="${pageContext.request.contextPath}/student/feedback?action=do" class="btn-start">
                            ✍️ Bắt đầu Làm bài Đánh giá
                        </a>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </main>
</body>
</html>
