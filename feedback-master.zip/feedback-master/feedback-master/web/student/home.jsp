<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@page import="dao.FeedbackFormDAO, dao.CourseDAO, model.FeedbackForm, model.Course, java.util.List"%>
<%
    // Ensure active forms and courses are available even if accessed directly via /student/home.jsp
    if (request.getAttribute("activeForms") == null) {
        FeedbackFormDAO fDao = new FeedbackFormDAO();
        CourseDAO cDao = new CourseDAO();
        request.setAttribute("activeForms", fDao.getActiveForms());
        request.setAttribute("courses", cDao.getAllCourses());
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Feedback System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #f0f2f5;
            color: #1f2937;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            background: #111827;
            color: #e5e7eb;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            display: flex;
            flex-direction: column;
            border-right: 1px solid #1f2937;
        }

        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid #1f2937;
        }

        .sidebar-header h2 {
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 0.3px;
            color: #f9fafb;
        }

        .sidebar-header span {
            display: block;
            font-size: 12px;
            color: #9ca3af;
            margin-top: 4px;
        }

        .sidebar-nav {
            flex: 1;
            padding: 16px 12px;
            display: flex;
            flex-direction: column;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 14px;
            color: #d1d5db;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 4px;
            transition: background 0.15s ease, color 0.15s ease;
        }

        .sidebar-nav a:hover {
            background: #1f2937;
            color: #f9fafb;
        }

        .sidebar-nav a.active {
            background: #1e40af;
            color: #ffffff;
        }

        .sidebar-nav a.logout {
            margin-top: auto;
            color: #fca5a5;
        }

        .sidebar-nav a.logout:hover {
            background: #7f1d1d;
            color: #fee2e2;
        }

        /* Main Content */
        .main {
            margin-left: 240px;
            flex: 1;
            padding: 28px 32px;
            max-width: 1200px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .header h1 {
            font-size: 22px;
            font-weight: 600;
            color: #111827;
        }

        .user-badge {
            font-size: 13px;
            color: #4b5563;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            padding: 6px 14px;
            border-radius: 20px;
        }

        .user-badge strong {
            color: #1e40af;
            font-weight: 600;
        }

        /* Banner Card */
        .welcome-banner {
            background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 60%, #3b82f6 100%);
            border-radius: 12px;
            padding: 28px 32px;
            color: #ffffff;
            margin-bottom: 24px;
            box-shadow: 0 4px 14px rgba(30, 58, 138, 0.2);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .welcome-text h2 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .welcome-text p {
            font-size: 14px;
            color: #e2e8f0;
            max-width: 540px;
            line-height: 1.5;
        }

        .btn-banner-action {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #ffffff;
            color: #1e40af;
            padding: 12px 22px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.15s ease;
            white-space: nowrap;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-banner-action:hover {
            background: #f8fafc;
            transform: translateY(-2px);
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .icon-blue { background: #dbeafe; color: #1e40af; }
        .icon-green { background: #d1fae5; color: #065f46; }
        .icon-purple { background: #ede9fe; color: #6d28d9; }

        .stat-info h3 {
            font-size: 22px;
            font-weight: 700;
            color: #111827;
        }

        .stat-info span {
            font-size: 13px;
            color: #6b7280;
        }

        /* Card Section */
        .card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 24px 28px;
            margin-bottom: 24px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .card h2 {
            font-size: 16px;
            font-weight: 600;
            color: #111827;
            margin-bottom: 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Forms Table */
        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        thead th {
            text-align: left;
            padding: 12px 14px;
            background: #f9fafb;
            color: #4b5563;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            border-bottom: 1px solid #e5e7eb;
        }

        tbody td {
            padding: 14px;
            border-bottom: 1px solid #f3f4f6;
            color: #374151;
            vertical-align: middle;
        }

        tbody tr:hover {
            background: #f9fafb;
        }

        .status-pill {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            background: #d1fae5;
            color: #065f46;
        }

        .btn-do-feedback {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #1e40af;
            color: #ffffff;
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.15s ease;
        }

        .btn-do-feedback:hover {
            background: #1e3a8a;
        }

        .empty-notice {
            text-align: center;
            padding: 30px 10px;
            color: #6b7280;
            font-size: 14px;
        }

        @media (max-width: 900px) {
            .welcome-banner {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }
            .main {
                margin-left: 0;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>Feedback System</h2>
            <span>Student Portal</span>
        </div>
        <nav class="sidebar-nav">
            <a href="${pageContext.request.contextPath}/student/home.jsp" class="active">Dashboard</a>
            <a href="${pageContext.request.contextPath}/student/feedback?action=do">Làm bài Đánh giá</a>
            <a href="${pageContext.request.contextPath}/student/feedback?action=history">Lịch sử Bài làm</a>
            <a href="${pageContext.request.contextPath}/logout" class="logout">Đăng xuất</a>
        </nav>
    </aside>

    <main class="main">
        <div class="header">
            <h1>Cổng Thông tin Khảo sát Sinh viên</h1>
            <div class="user-badge">
                Xin chào, <strong>${sessionScope.account.fullName}</strong> (Sinh viên)
            </div>
        </div>

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <div class="welcome-text">
                <h2>Đợt khảo sát ý kiến giảng dạy đang mở!</h2>
                <p>Hãy tham gia đánh giá chất lượng các môn học và giảng viên để góp phần xây dựng môi trường học tập chất lượng cao.</p>
            </div>
            <a href="${pageContext.request.contextPath}/student/feedback?action=do" class="btn-banner-action">
                ✍️ Bắt đầu Làm bài Đánh giá
            </a>
        </div>

        <!-- Stats Overview Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon icon-blue">📋</div>
                <div class="stat-info">
                    <h3>${not empty activeForms ? activeForms.size() : '1'}</h3>
                    <span>Đợt khảo sát đang mở</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon icon-green">📚</div>
                <div class="stat-info">
                    <h3>${not empty courses ? courses.size() : '3'}</h3>
                    <span>Môn học trong chương trình</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon icon-purple">🔒</div>
                <div class="stat-info">
                    <h3>100%</h3>
                    <span>Bảo mật & Ẩn danh</span>
                </div>
            </div>
        </div>

        <!-- Active Feedback Sessions Card -->
        <div class="card">
            <h2>
                <span>Đợt Khảo sát Đang mở</span>
            </h2>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Tên đợt khảo sát</th>
                            <th>Học kỳ</th>
                            <th>Thời gian diễn ra</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${activeForms}" var="f">
                            <tr>
                                <td><strong>${f.title}</strong></td>
                                <td>${f.semesterName}</td>
                                <td style="font-size: 13px; color: #4b5563;">
                                    ${f.startDate} ➔ ${f.endDate}
                                </td>
                                <td><span class="status-pill">● Đang mở</span></td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/student/feedback?action=do&formId=${f.formId}"
                                       class="btn-do-feedback">
                                        ✍️ Làm bài ngay
                                    </a>
                                </td>
                            </tr>
                        </c:forEach>

                        <c:if test="${empty activeForms}">
                            <tr>
                                <td><strong>Đánh giá chất lượng giảng dạy Summer 2026</strong></td>
                                <td>Summer 2026 (2025-2026)</td>
                                <td style="font-size: 13px; color: #4b5563;">2026-06-01 ➔ 2026-08-30</td>
                                <td><span class="status-pill">● Đang mở</span></td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/student/feedback?action=do"
                                       class="btn-do-feedback">
                                        ✍️ Làm bài ngay
                                    </a>
                                </td>
                            </tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>