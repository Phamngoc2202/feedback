package controller;

import dao.CourseDAO;
import dao.FeedbackFormDAO;
import dao.UserDAO;
import model.Course;
import model.FeedbackForm;
import model.User;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "StudentFeedbackServlet", urlPatterns = {"/student/feedback"})
public class StudentFeedbackServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User account = (User) session.getAttribute("account");
        
        if (account == null || account.getRoleId() != 3) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        FeedbackFormDAO formDAO = new FeedbackFormDAO();
        CourseDAO courseDAO = new CourseDAO();
        UserDAO userDAO = new UserDAO();

        if ("do".equals(action)) {
            // Hiển thị giao diện làm bài đánh giá
            int formId = 0;
            try {
                formId = Integer.parseInt(request.getParameter("formId"));
            } catch (Exception e) {}

            FeedbackForm form = formDAO.getFormById(formId);
            if (form == null) {
                List<FeedbackForm> activeForms = formDAO.getActiveForms();
                if (!activeForms.isEmpty()) {
                    form = activeForms.get(0);
                }
            }

            List<Course> courses = courseDAO.getAllCourses();
            List<User> teachers = userDAO.getTeachers();

            request.setAttribute("currentForm", form);
            request.setAttribute("courseList", courses);
            request.setAttribute("teacherList", teachers);
            request.getRequestDispatcher("/student/do_feedback.jsp").forward(request, response);
            return;
        } else if ("history".equals(action)) {
            // Hiển thị lịch sử các bài đánh giá đã làm
            List<Map<String, Object>> historyList = (List<Map<String, Object>>) session.getAttribute("studentFeedbackHistory");
            if (historyList == null) {
                historyList = new ArrayList<>();
            }
            request.setAttribute("historyList", historyList);
            request.getRequestDispatcher("/student/feedback_history.jsp").forward(request, response);
            return;
        }

        // Mặc định: tải danh sách đợt khảo sát & môn học để hiển thị Dashboard
        List<FeedbackForm> activeForms = formDAO.getActiveForms();
        List<Course> courses = courseDAO.getAllCourses();
        List<User> teachers = userDAO.getTeachers();

        request.setAttribute("activeForms", activeForms);
        request.setAttribute("courses", courses);
        request.setAttribute("teachers", teachers);
        request.getRequestDispatcher("/student/home.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession();
        User account = (User) session.getAttribute("account");
        if (account == null || account.getRoleId() != 3) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String formIdStr = request.getParameter("formId");
        String courseIdStr = request.getParameter("courseId");
        String teacherIdStr = request.getParameter("teacherId");
        String comments = request.getParameter("comments");

        // Lấy điểm các tiêu chí (1 đến 9)
        int totalScore = 0;
        int questionsCount = 9;
        Map<String, Integer> answers = new HashMap<>();

        for (int i = 1; i <= questionsCount; i++) {
            String val = request.getParameter("q" + i);
            int score = (val != null && !val.isEmpty()) ? Integer.parseInt(val) : 5;
            answers.put("q" + i, score);
            totalScore += score;
        }

        double averageScore = (double) totalScore / questionsCount;
        String formattedAvg = String.format("%.1f", averageScore);

        // Lấy thông tin môn học & giảng viên
        int courseId = 0;
        try {
            courseId = Integer.parseInt(courseIdStr);
        } catch (Exception e) {}

        int formId = 0;
        try {
            formId = Integer.parseInt(formIdStr);
        } catch (Exception e) {}

        CourseDAO courseDAO = new CourseDAO();
        FeedbackFormDAO formDAO = new FeedbackFormDAO();
        UserDAO userDAO = new UserDAO();

        FeedbackForm currentForm = formDAO.getFormById(formId);
        String formTitle = (currentForm != null) ? currentForm.getTitle() : "Đợt khảo sát ý kiến sinh viên";
        String semesterName = (currentForm != null) ? currentForm.getSemesterName() : "Học kỳ hiện tại";

        List<Course> allCourses = courseDAO.getAllCourses();
        String courseName = "Môn học";
        String courseCode = "";
        for (Course c : allCourses) {
            if (c.getCourseId() == courseId) {
                courseName = c.getCourseName();
                courseCode = c.getCourseCode();
                break;
            }
        }

        int teacherId = 0;
        try {
            teacherId = Integer.parseInt(teacherIdStr);
        } catch (Exception e) {}

        List<User> allTeachers = userDAO.getTeachers();
        String teacherName = "Giảng viên bộ môn";
        for (User t : allTeachers) {
            if (t.getUserId() == teacherId) {
                teacherName = t.getFullName();
                break;
            }
        }

        // Tạo mã biên nhận & thời gian nộp
        String submissionId = "FB" + System.currentTimeMillis() % 1000000;
        String submittedTime = new SimpleDateFormat("HH:mm:ss - dd/MM/yyyy").format(new Date());

        // Lưu vào danh sách lịch sử trong Session
        List<Map<String, Object>> historyList = (List<Map<String, Object>>) session.getAttribute("studentFeedbackHistory");
        if (historyList == null) {
            historyList = new ArrayList<>();
        }

        Map<String, Object> record = new HashMap<>();
        record.put("submissionId", submissionId);
        record.put("formTitle", formTitle);
        record.put("semesterName", semesterName);
        record.put("courseCode", courseCode);
        record.put("courseName", courseName);
        record.put("teacherName", teacherName);
        record.put("averageScore", formattedAvg);
        record.put("submittedTime", submittedTime);
        record.put("comments", (comments != null && !comments.trim().isEmpty()) ? comments.trim() : "Không có ý kiến thêm.");
        record.put("answers", answers);

        historyList.add(0, record);
        session.setAttribute("studentFeedbackHistory", historyList);

        // Truyền dữ liệu sang trang thành công
        request.setAttribute("submission", record);
        request.getRequestDispatcher("/student/feedback_success.jsp").forward(request, response);
    }
}
