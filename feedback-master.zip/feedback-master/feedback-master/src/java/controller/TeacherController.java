package controller;

import dao.FeedbackFormDAO;
import dao.TeacherDAO;
import model.CriteriaRating;
import model.FeedbackDetail;
import model.FeedbackReply;
import model.Semester;
import model.TeacherClass;
import model.User;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "TeacherController", urlPatterns = {"/teacher/home", "/teacher/feedback", "/teacher/dashboard"})
public class TeacherController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User account = (User) session.getAttribute("account");

        // Kiểm tra phân quyền: Chỉ dành cho Giảng viên (role_id = 2)
        if (account == null || account.getRoleId() != 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        TeacherDAO teacherDAO = new TeacherDAO();
        FeedbackFormDAO formDAO = new FeedbackFormDAO();

        // 1. Nhận các bộ lọc
        int semesterId = 0;
        try {
            String semParam = request.getParameter("semesterId");
            if (semParam != null && !semParam.isEmpty()) {
                semesterId = Integer.parseInt(semParam);
            }
        } catch (Exception e) {}

        int classId = 0;
        try {
            String classParam = request.getParameter("classId");
            if (classParam != null && !classParam.isEmpty()) {
                classId = Integer.parseInt(classParam);
            }
        } catch (Exception e) {}

        // 2. Lấy dữ liệu học kỳ & danh sách lớp
        List<Semester> semesterList = formDAO.getAllSemesters();
        List<TeacherClass> teacherClasses = teacherDAO.getClassesByTeacher(account.getUserId(), semesterId);

        // Mặc định chọn lớp đầu tiên nếu chưa chọn lớp nào
        if (classId <= 0 && !teacherClasses.isEmpty()) {
            classId = teacherClasses.get(0).getClassId();
        }

        TeacherClass currentClass = null;
        for (TeacherClass tc : teacherClasses) {
            if (tc.getClassId() == classId) {
                currentClass = tc;
                break;
            }
        }
        if (currentClass == null && !teacherClasses.isEmpty()) {
            currentClass = teacherClasses.get(0);
            classId = currentClass.getClassId();
        }

        // 3. Lấy điểm 9 tiêu chí và danh sách ý kiến phản hồi
        List<CriteriaRating> criteriaList = teacherDAO.getCriteriaRatings(account.getUserId(), classId);
        List<FeedbackDetail> feedbackList = teacherDAO.getFeedbacksByClass(account.getUserId(), classId);

        // 4. Tính toán số liệu thống kê tổng thể KPI
        int totalClasses = teacherClasses.size();
        int totalFeedbacks = 0;
        int totalStudents = 0;
        double sumRating = 0.0;
        for (TeacherClass tc : teacherClasses) {
            totalFeedbacks += tc.getFeedbackCount();
            totalStudents += tc.getTotalStudents();
            sumRating += tc.getAverageRating();
        }
        double overallRating = totalClasses > 0 ? (Math.round((sumRating / totalClasses) * 10.0) / 10.0) : 5.0;
        double avgResponseRate = totalStudents > 0 ? (Math.round(((double) totalFeedbacks / totalStudents) * 1000.0) / 10.0) : 0.0;

        // 5. Đẩy dữ liệu sang View (home.jsp)
        request.setAttribute("semesterList", semesterList);
        request.setAttribute("currentSemesterId", semesterId);
        request.setAttribute("teacherClasses", teacherClasses);
        request.setAttribute("selectedClassId", classId);
        request.setAttribute("currentClass", currentClass);
        request.setAttribute("criteriaList", criteriaList);
        request.setAttribute("feedbackList", feedbackList);

        request.setAttribute("totalClasses", totalClasses);
        request.setAttribute("totalFeedbacks", totalFeedbacks);
        request.setAttribute("totalStudents", totalStudents);
        request.setAttribute("overallRating", overallRating);
        request.setAttribute("avgResponseRate", avgResponseRate);

        request.getRequestDispatcher("/teacher/home.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession();
        User account = (User) session.getAttribute("account");

        if (account == null || account.getRoleId() != 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        String classIdStr = request.getParameter("classId");
        int classId = 0;
        try {
            classId = Integer.parseInt(classIdStr);
        } catch (Exception e) {}

        if ("reply".equals(action)) {
            String feedbackIdStr = request.getParameter("feedbackId");
            String replyContent = request.getParameter("replyContent");

            if (feedbackIdStr != null && replyContent != null && !replyContent.trim().isEmpty()) {
                int feedbackId = Integer.parseInt(feedbackIdStr);
                FeedbackReply reply = new FeedbackReply(
                    0,
                    feedbackId,
                    account.getUserId(),
                    account.getFullName(),
                    replyContent.trim(),
                    new Date()
                );

                TeacherDAO teacherDAO = new TeacherDAO();
                boolean ok = teacherDAO.insertFeedbackReply(reply);
                if (ok) {
                    session.setAttribute("msgSuccess", "Đã đăng câu trả lời phản hồi thành công đến sinh viên!");
                } else {
                    session.setAttribute("msgError", "Có lỗi xảy ra khi lưu câu trả lời!");
                }
            } else {
                session.setAttribute("msgError", "Vui lòng nhập nội dung câu trả lời!");
            }
        }

        // Chuyển hướng lại trang lớp học tương ứng
        String redirectUrl = request.getContextPath() + "/teacher/home" + (classId > 0 ? ("?classId=" + classId) : "");
        response.sendRedirect(redirectUrl);
    }
}
