package controller;

import dao.UserDAO;
import model.User;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User account = (User) session.getAttribute("account");

        // Nếu đã đăng nhập thì điều hướng đến dashboard tương ứng
        if (account != null) {
            redirectByRole(account.getRoleId(), request, response);
            return;
        }
        request.getRequestDispatcher("register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("username");
        String fullName = request.getParameter("fullname");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String roleIdParam = request.getParameter("roleId");

        // 1. Kiểm tra các trường bắt buộc
        if (username == null || username.trim().isEmpty()
                || password == null || password.trim().isEmpty()
                || confirmPassword == null || confirmPassword.trim().isEmpty()
                || fullName == null || fullName.trim().isEmpty()) {
            request.setAttribute("error", "Vui lòng nhập đầy đủ các thông tin bắt buộc!");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        username = username.trim();
        fullName = fullName.trim();
        email = (email != null) ? email.trim() : "";

        // 2. Validate định dạng & độ dài
        if (username.length() < 3 || username.length() > 50) {
            request.setAttribute("error", "Tên đăng nhập phải từ 3 đến 50 ký tự!");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        if (username.contains(" ")) {
            request.setAttribute("error", "Tên đăng nhập không được chứa khoảng trắng!");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        if (password.length() < 6) {
            request.setAttribute("error", "Mật khẩu phải có ít nhất 6 ký tự!");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        // 3. Kiểm tra mật khẩu xác nhận
        if (!password.equals(confirmPassword)) {
            request.setAttribute("error", "Mật khẩu xác nhận không trùng khớp!");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        // 4. Validate Email nếu có nhập
        if (!email.isEmpty() && !email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            request.setAttribute("error", "Định dạng email không hợp lệ!");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        // Phân quyền: mặc định 3 (Student), cho phép chọn 2 (Teacher) hoặc 3 (Student)
        int roleId = 3;
        if (roleIdParam != null && !roleIdParam.trim().isEmpty()) {
            try {
                int parsed = Integer.parseInt(roleIdParam.trim());
                if (parsed == 2 || parsed == 3) {
                    roleId = parsed;
                }
            } catch (NumberFormatException e) {
                roleId = 3;
            }
        }

        UserDAO dao = new UserDAO();

        // 5. Kiểm tra tên đăng nhập đã tồn tại
        if (dao.checkUsernameExists(username)) {
            request.setAttribute("error", "Tên đăng nhập '" + username + "' đã được sử dụng. Vui lòng chọn tên khác!");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        // 6. Kiểm tra email đã tồn tại (nếu có nhập email)
        if (!email.isEmpty() && dao.checkEmailExists(email)) {
            request.setAttribute("error", "Email '" + email + "' đã được sử dụng. Vui lòng nhập email khác!");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        // 7. Thực hiện thêm tài khoản mới
        User newUser = new User(0, username, password, fullName, email, roleId);
        boolean isSuccess = dao.insertUser(newUser);

        if (isSuccess) {
            request.setAttribute("success", "Đăng ký tài khoản thành công! Vui lòng đăng nhập.");
            request.setAttribute("username", username);
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "Đăng ký thất bại do lỗi hệ thống! Vui lòng thử lại.");
            preserveFormInputs(request, username, fullName, email, roleIdParam);
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }

    private void preserveFormInputs(HttpServletRequest request, String username, String fullName, String email, String roleId) {
        request.setAttribute("regUsername", username);
        request.setAttribute("regFullName", fullName);
        request.setAttribute("regEmail", email);
        request.setAttribute("regRoleId", roleId);
    }

    private void redirectByRole(int roleId, HttpServletRequest request, HttpServletResponse response) throws IOException {
        String contextPath = request.getContextPath();
        if (roleId == 1) {
            response.sendRedirect(contextPath + "/admin/home.jsp");
        } else if (roleId == 2) {
            response.sendRedirect(contextPath + "/teacher/home");
        } else if (roleId == 3) {
            response.sendRedirect(contextPath + "/student/home.jsp");
        }
    }
}
