package model;

import java.util.Date;

public class FeedbackReply {
    private int replyId;
    private int feedbackId;
    private int teacherId;
    private String teacherName;
    private String replyContent;
    private Date createdAt;

    public FeedbackReply() {
    }

    public FeedbackReply(int replyId, int feedbackId, int teacherId, String teacherName, String replyContent, Date createdAt) {
        this.replyId = replyId;
        this.feedbackId = feedbackId;
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.replyContent = replyContent;
        this.createdAt = createdAt;
    }

    public int getReplyId() { return replyId; }
    public void setReplyId(int replyId) { this.replyId = replyId; }

    public int getFeedbackId() { return feedbackId; }
    public void setFeedbackId(int feedbackId) { this.feedbackId = feedbackId; }

    public int getTeacherId() { return teacherId; }
    public void setTeacherId(int teacherId) { this.teacherId = teacherId; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }

    public String getReplyContent() { return replyContent; }
    public void setReplyContent(String replyContent) { this.replyContent = replyContent; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
}
