package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FeedbackDetail {
    private int feedbackId;
    private int formId;
    private String formTitle;
    private int classId;
    private String classCode;
    private int courseId;
    private String courseName;
    private int teacherId;
    private String studentName; // Ẩn danh hoặc mã sinh viên
    private int[] scores = new int[9]; // q1 đến q9
    private double averageScore;
    private String comments;
    private Date createdAt;
    private List<FeedbackReply> replies = new ArrayList<>();

    public FeedbackDetail() {
    }

    public FeedbackDetail(int feedbackId, int formId, String formTitle, int classId, String classCode, 
                          int courseId, String courseName, int teacherId, String studentName, 
                          int[] scores, double averageScore, String comments, Date createdAt) {
        this.feedbackId = feedbackId;
        this.formId = formId;
        this.formTitle = formTitle;
        this.classId = classId;
        this.classCode = classCode;
        this.courseId = courseId;
        this.courseName = courseName;
        this.teacherId = teacherId;
        this.studentName = studentName;
        this.scores = scores;
        this.averageScore = averageScore;
        this.comments = comments;
        this.createdAt = createdAt;
    }

    public int getFeedbackId() { return feedbackId; }
    public void setFeedbackId(int feedbackId) { this.feedbackId = feedbackId; }

    public int getFormId() { return formId; }
    public void setFormId(int formId) { this.formId = formId; }

    public String getFormTitle() { return formTitle; }
    public void setFormTitle(String formTitle) { this.formTitle = formTitle; }

    public int getClassId() { return classId; }
    public void setClassId(int classId) { this.classId = classId; }

    public String getClassCode() { return classCode; }
    public void setClassCode(String classCode) { this.classCode = classCode; }

    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public int getTeacherId() { return teacherId; }
    public void setTeacherId(int teacherId) { this.teacherId = teacherId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public int[] getScores() { return scores; }
    public void setScores(int[] scores) { this.scores = scores; }

    public double getAverageScore() { return averageScore; }
    public void setAverageScore(double averageScore) { this.averageScore = averageScore; }

    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public List<FeedbackReply> getReplies() { return replies; }
    public void setReplies(List<FeedbackReply> replies) { this.replies = replies; }
    
    public void addReply(FeedbackReply reply) {
        if (this.replies == null) {
            this.replies = new ArrayList<>();
        }
        this.replies.add(reply);
    }
}
