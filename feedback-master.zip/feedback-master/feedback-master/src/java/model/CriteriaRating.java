package model;

public class CriteriaRating {
    private int criteriaNumber;
    private String criteriaCode;
    private String criteriaTitle;
    private String category;
    private double averageScore;
    private int totalResponses;

    public CriteriaRating() {
    }

    public CriteriaRating(int criteriaNumber, String criteriaCode, String criteriaTitle, String category, double averageScore, int totalResponses) {
        this.criteriaNumber = criteriaNumber;
        this.criteriaCode = criteriaCode;
        this.criteriaTitle = criteriaTitle;
        this.category = category;
        this.averageScore = averageScore;
        this.totalResponses = totalResponses;
    }

    public int getCriteriaNumber() { return criteriaNumber; }
    public void setCriteriaNumber(int criteriaNumber) { this.criteriaNumber = criteriaNumber; }

    public String getCriteriaCode() { return criteriaCode; }
    public void setCriteriaCode(String criteriaCode) { this.criteriaCode = criteriaCode; }

    public String getCriteriaTitle() { return criteriaTitle; }
    public void setCriteriaTitle(String criteriaTitle) { this.criteriaTitle = criteriaTitle; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getAverageScore() { return averageScore; }
    public void setAverageScore(double averageScore) { this.averageScore = averageScore; }

    public int getTotalResponses() { return totalResponses; }
    public void setTotalResponses(int totalResponses) { this.totalResponses = totalResponses; }

    public double getScorePercentage() {
        return Math.round((averageScore / 5.0) * 1000.0) / 10.0;
    }

    public String getEvaluationLevel() {
        if (averageScore >= 4.5) return "Xuất sắc";
        if (averageScore >= 4.0) return "Tốt";
        if (averageScore >= 3.0) return "Đạt";
        return "Cần cải thiện";
    }

    public String getBadgeClass() {
        if (averageScore >= 4.5) return "badge-excellent";
        if (averageScore >= 4.0) return "badge-good";
        if (averageScore >= 3.0) return "badge-average";
        return "badge-poor";
    }
}
