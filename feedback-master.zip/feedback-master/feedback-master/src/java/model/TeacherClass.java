package model;

public class TeacherClass {
    private int classId;
    private String classCode;
    private int courseId;
    private String courseCode;
    private String courseName;
    private int credits;
    private int semesterId;
    private String semesterName;
    private int teacherId;
    private int totalStudents;
    private int feedbackCount;
    private double averageRating;

    public TeacherClass() {
    }

    public TeacherClass(int classId, String classCode, int courseId, String courseCode, String courseName, 
                        int credits, int semesterId, String semesterName, int teacherId, 
                        int totalStudents, int feedbackCount, double averageRating) {
        this.classId = classId;
        this.classCode = classCode;
        this.courseId = courseId;
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.credits = credits;
        this.semesterId = semesterId;
        this.semesterName = semesterName;
        this.teacherId = teacherId;
        this.totalStudents = totalStudents;
        this.feedbackCount = feedbackCount;
        this.averageRating = averageRating;
    }

    public int getClassId() { return classId; }
    public void setClassId(int classId) { this.classId = classId; }

    public String getClassCode() { return classCode; }
    public void setClassCode(String classCode) { this.classCode = classCode; }

    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }

    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }

    public int getSemesterId() { return semesterId; }
    public void setSemesterId(int semesterId) { this.semesterId = semesterId; }

    public String getSemesterName() { return semesterName; }
    public void setSemesterName(String semesterName) { this.semesterName = semesterName; }

    public int getTeacherId() { return teacherId; }
    public void setTeacherId(int teacherId) { this.teacherId = teacherId; }

    public int getTotalStudents() { return totalStudents; }
    public void setTotalStudents(int totalStudents) { this.totalStudents = totalStudents; }

    public int getFeedbackCount() { return feedbackCount; }
    public void setFeedbackCount(int feedbackCount) { this.feedbackCount = feedbackCount; }

    public double getAverageRating() { return averageRating; }
    public void setAverageRating(double averageRating) { this.averageRating = averageRating; }

    public double getResponseRate() {
        if (totalStudents <= 0) return 0.0;
        return Math.round(((double) feedbackCount / totalStudents) * 1000.0) / 10.0;
    }
}
