package filter;

import model.User;
import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter(filterName = "AuthorizationFilter", urlPatterns = {"/*"})
public class AuthorizationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession();
        
        String uri = req.getRequestURI();
        String contextPath = req.getContextPath();
        String path = uri.substring(contextPath.length());
        
        User account = (User) session.getAttribute("account");

        // 1. Cho phép truy cập trực tiếp các tài nguyên tĩnh (.css, .js, .png, .jpg, v.v.)
        if (path.endsWith(".css") || path.endsWith(".js") || path.endsWith(".png") 
            || path.endsWith(".jpg") || path.endsWith(".jpeg") || path.endsWith(".svg") 
            || path.endsWith(".ico") || path.endsWith(".woff") || path.endsWith(".woff2")
            || path.contains("/css/") || path.contains("/images/") || path.contains("/js/")) {
            chain.doFilter(request, response);
            return;
        }

        // 2. Bỏ qua các trang công khai: login, register, logout
        if (path.equals("/login") || path.equals("/login.jsp") 
            || path.equals("/register") || path.equals("/register.jsp") 
            || path.equals("/logout") || path.equals("/") || path.equals("/index.html")) {
            
            // Nếu đã đăng nhập mà lại vào /login hoặc /register thì chuyển tiếp về trang chủ của role
            if (account != null && (path.equals("/login") || path.equals("/login.jsp") || path.equals("/register") || path.equals("/register.jsp"))) {
                redirectByRole(account.getRoleId(), req, res);
                return;
            }
            chain.doFilter(request, response);
            return;
        }

        // 3. Chặn người dùng chưa đăng nhập khi vào các trang nội bộ
        if (account == null) {
            session.setAttribute("error", "Vui lòng đăng nhập để tiếp tục!");
            res.sendRedirect(contextPath + "/login");
            return;
        }

        int roleId = account.getRoleId();

        // 4. Chặn người dùng vào sai vai trò (Role-based access control)
        // Role 1: Admin
        if (path.startsWith("/admin/") && roleId != 1) {
            res.sendRedirect(contextPath + "/login");
            return;
        }

        // Role 2: Teacher
        if (path.startsWith("/teacher/") && roleId != 2) {
            res.sendRedirect(contextPath + "/login");
            return;
        }

        // Role 3: Student
        if (path.startsWith("/student/") && roleId != 3) {
            res.sendRedirect(contextPath + "/login");
            return;
        }

        // 5. Nếu giảng viên truy cập trực tiếp file teacher/home.jsp -> chuyển hướng sang TeacherController (/teacher/home) để load dữ liệu
        if (path.equals("/teacher/home.jsp")) {
            res.sendRedirect(contextPath + "/teacher/home");
            return;
        }

        chain.doFilter(request, response);
    }

    private void redirectByRole(int roleId, HttpServletRequest request, HttpServletResponse response) throws IOException {
        String contextPath = request.getContextPath();
        if (roleId == 1) {
            response.sendRedirect(contextPath + "/admin/home.jsp");
        } else if (roleId == 2) {
            response.sendRedirect(contextPath + "/teacher/home");
        } else if (roleId == 3) {
            response.sendRedirect(contextPath + "/student/home.jsp");
        } else {
            response.sendRedirect(contextPath + "/login");
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}
}